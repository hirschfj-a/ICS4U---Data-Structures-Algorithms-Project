//--------SKETCH----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

let simulation;
let driver
let customer
//let request (or node)
//let event

function setup() 
{
 // print("Hello World!")
  createCanvas(720, 400); //13 squares X, 10 squares Y    //720 is 520+200
  simulation = new SimulationController(width, height);
  
  frameRate(60)
//  print(frameCount)
  
  customer = new Customer()
  
 // driver = new Driver()
   //driver.starthome() //list n
  
  
  listc = new LinkedList() //linked list instance for requests (customers)
  listd = new LinkedList() //linked list instance for drivers
  
  listlog = new LinkedList() //linked list used for logging information
  
  
  for(i = 1; i<=4; i++) //4 for default, then turns into 8 after refresh
    {
  listc.insertcustomer()
   }
  
  
   for(i = 1; i<=2; i++) //2 for default
    {
      listd.insertdriver()
    }
  
  
  //implement next!
  listlog.insertloginformation() //1
  
  
  
   // for(i = 1; i<=9; i++) //FOR TESTING
   //  {
   //    listd.insertdriver()
   //  }
  
  // for(i = 1; i<=round(random(2,4)); i++) //2 for default
   //  {//////// FOR TESTING
   //    listd.insertdriver()
   //  }
  
  listd.displaylist()  //prints out the linked lists and shows the data inside
  listc.displaylist()
  customer.setcustomerstart() //prints out the information for the customer and starts the customer at the first point
  
  listlog.displaylist()

  
}

function draw() 
{
  background(245);
  simulation.update();
  simulation.display();
  
  listd.drivercommands() //keeps drivers updated by scrolling through the drivers and allowing them to update
  
 // simulation.updatespeed();
  
  customer.display()
  customer.managelist()
  
  
  for(let i = 0; i<=13; i++)
    {
      fill('pink')
      text(i,i*39+5,10)
    }
  
  for(let i = 1; i<=10; i++)
    {
      fill('pink')
      text(i,5,i*40)
    }
  
 // print(listd.driverthatisbusy)
 // print(customer.beingserved)
 //  print(customer.currentcustomer)
 // print(customer.firsttestcustomer)
  
  //print(customer.lastcustomerserved)
//  print(customer.doneservingallcustomers)
//   print("node being displayed:")
//   print(customer.currentcustomerdisplaynode)
  
//   print("currentnode")
//   print(customer.currentcustomer)
  
 //  print(listd.driverwithgoodmood)
 // print(listd.driverwithmatchingmusic)
  
 // print(listlog)
  
}

function mouseReleased() //for testing and more!
{
  print("Hello!")
  print("-----")
  
 // print(listd.driverwithgoodmood)
 // print(listd.driverwithmatchingmusic)
  
  //print(listd.currentdriver.capacity)
  
  if(mouseX > 530)
  simulation.updatespeed();
  
 // print(simulation.simulationspeed)
  
 // print(listd.currentdriver)
  //print(listd.currentdriver.speed)
  
  
 // listc.search(4)
  
//  listd.search(2)
  
  
  
 // customer.refreshing = true
  
//  listc.displaylist()
 // listd.displaylist()
  
  print("-----")
}