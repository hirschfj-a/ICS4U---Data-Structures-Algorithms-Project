


class EventNode
{ //links or Nodes
  constructor(id,eventtype) 
  { //request id
    this.id = id; //id
    this.next = null;
    
    this.eventtype = eventtype; //0 means that it is the head of the list and marks the start of a series of customers. 1 means that a driver sees a customer and matched with a customer, 2 means that the customer was served! 4 means that the match expired between the driver and the customer, while 3 means that the match was overridden by a driver with better conditions
  }
  
  firstevent() //let the first stay constant
  {
    
    if(this.id == 1) //marks the start of the list
    this.eventtype = 0
    
  }
  
  create() //creates an event
  {
    
    
    
  }
  
  
}