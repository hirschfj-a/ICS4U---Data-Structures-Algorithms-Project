//--------DRIVER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------




class Driver 
{
  constructor(id, location, x, y, speed, capacity, capacitynormaldistribution, goodmoodset, favouritemusic) 
  {
    this.location = { x: x, y: y };
    this.savedxlocation = -1;
    this.savedylocation = -1;
    this.horizontal = true;
    this.speed = 2; //1 or 2 is default
    
    this.homelocation = createVector(x,y)
    this.drawnhome = false;
    this.onlyonce = true //runs commands only once in the beginning
    
    this.servingcustomer = false;
    
    
    this.id = id;
    this.next = null;
    
    
    this.capacitynormaldistribution = capacitynormaldistribution
    this.capacity = capacity
    this.capable = true;
    this.canholdanycustomer = false; //for driver #1
    
    
    //amenities:
      this.goodmoodset = goodmoodset; //options: 1,0  //1 is in a good mood, 0 is not in a good mood
      this.favouritemusic = favouritemusic; //options: 0,1,2,3,4,5 //0 loves all music, the other numbers represent other genres of music
      this.musicmatch = true; //does the music match the customer?
      this.goodmood = true;
    
      this.mostidealconditions = true;
    
      this.correctedpos = false; //will become true when the position is corrected (stops driver from slipping off the grid)
    
 
    this.status = "AVAILABLE"; //AVAILABLE,BUSY,CARRYING,RESTING
    this.currentRide = null;
    this.busyTimer = 0;
    this.busymultiply = 1;
    this.restingTimer = 500; //500 or 90
    
    this.broadcastconnection = false; //has this driver already broadcast their connection to the customer?
    this.broadcastexpire = false; //has this driver already broadcast their connection being expired?
    this.broadcastoverride = false; //has this driver already broadcast their connection being an override?
    this.broadcastservedcustomer = false; //has this driver already broadcast serving their customer?
    this.broadcastsimulationrefresh = false;
    this.broadcastfailedcustomer = false;
    
    this.broadcastmyevent = -1; //the number corresponds to the eventtype number and will create the eventtype's number
    
    this.scannedservecustomer = false; //only runs once when the servecustomer() method is running (supports broadcasting the overtakes)
    
    this.distancex = -1;
    this.distancey = -1;
    this.distance = -1;
    
    this.closestdistance = false; //set to false by default
    
    
    this.athome = true;
    
    this.checkeddriver1once = false;
    
  }

  assignRide(request, duration) 
  { 
    this.status = "BUSY";
    this.currentRide = request;
    this.busyTimer = duration;
    
    if(this.location.x == 40*1 && this.location.y == 40*2) //if at home?
      {
    this.horizontal = true
  //  print("i see the customer")
      }
  }
  
  
  
  
  servecustomer() //this method is called for by another 
  {
    
    this.athome = false
    
    if(listd.driverthatisbusy == false && this.scannedservecustomer == false)
      {
        
    if(this.broadcastconnection == false && customer.refreshing == false)
      {
        this.broadcastmyevent = 1; //broad cast this event!
        listlog.insertloginformation()
        this.broadcastmyevent = -1;
        
        this.broadcastconnection = true
      }
        
      }
    
    
   //if there is already a driver that is busy (this driver is overtaking)
    if(listd.driverthatisbusy == true && this.scannedservecustomer == false)
        {
                   
        if(this.broadcastoverride == false && customer.refreshing == false)
         {
           this.broadcastmyevent = 3; //broad cast this event!
           listlog.insertloginformation()
           this.broadcastmyevent = -1;
                  
           this.broadcastoverride = true
        }
            
         }
    
    
    
    stroke('magenta')
    
        
        listd.driverthatisbusy = true; //this driver will tell the whole list that a driver is busy
    
        customer.beingserved = true;
        this.servingcustomer = true;
        

   line(this.location.x,this.location.y,customer.location.x,this.location.y)
   line(customer.location.x,customer.location.y,customer.location.x,this.location.y)
        
        if(this.horizontal == true)
          {
    //       print("trying to go horizontal!")
        if(this.location.x < customer.location.x)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.location.x)
      this.location.x = this.location.x - this.speed
      
       //check within a range to prevent driver from being stuck!
      if(this.location.x > customer.location.x - 10 && this.location.x < customer.location.x || this.location.x < customer.location.x + 10 && this.location.x > customer.location.x) 
        {
          this.location.x = customer.location.x
        }
            
      if(this.location.x == customer.location.x)
         this.horizontal = false
       
          }
        
        else if (this.horizontal == false)
          {
      //      print("trying to go vertical!")
            
        if(this.location.y < customer.location.y)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.location.y)
      this.location.y = this.location.y - this.speed
            
        //check within a range to prevent driver from being stuck!
      if(this.location.y > customer.location.y - 10 && this.location.y < customer.location.y || this.location.y < customer.location.y + 10 && this.location.y > customer.location.y) 
        {
          this.location.y = customer.location.y
        }
      
            
            
          if(this.location.y == customer.location.y)
            {
      //        print("i made it to the customer!")
              this.horizontal = true
              this.status = "CARRYING"
              
              customer.displayfinallocation()
           //this part will make the driver carry the customer to their final location, and the driver has fully committed to serving the customer
              
            }
            
          }
    

    
    this.scannedservecustomer = true; //!
    
  }
  
  donotservecustomer() // this method is called
  {
    
    this.horizontal = true
        this.status = "RESTING" //or resting or available
    
    this.athome = true
        
        customer.beingserved = false;
        this.servingcustomer = false;
        
        this.currentRide = null;
    
  }
  
  
  finishservingcustomer() //called when the customer is served fully or customer expires
  {
    
     if(customer.refreshing == false)
                {
                  
                  
       //create rating:
                  
     if(customer.failedreachingcustomer == false) //reached customer successfully?
       {
          
         if(this.goodmood == true && this.musicmatch == true)
        customer.customerrating = round(random(4,5))
        
         else if(this.goodmood == true && this.musicmatch == false)
         customer.customerrating = round(random(3,5))
        
         else if(this.goodmood == false && this.musicmatch == true)
         customer.customerrating = round(random(3,4))
         
         else if(this.goodmood == false && this.musicmatch == false)
         customer.customerrating = round(random(3,3))
                  
                  
               //   print(customer.customerrating)
                  
     if(customer.timeelapsed >= 0 && customer.timeelapsed < 500)
       customer.customerrating = customer.customerrating + round(random(1,2))
                  
     else if(customer.timeelapsed >= 500 && customer.timeelapsed < 1000)
       customer.customerrating = customer.customerrating + round(random(0,1))
     
                  
     else if(customer.timeelapsed >= 1000 && customer.timeelapsed < 1500)
       customer.customerrating = customer.customerrating - round(random(1,2))
                  
     else if(customer.timeelapsed >= 1500)
       customer.customerrating = customer.customerrating - round(random(2,5))
         
       }
                  
    if(customer.failedreachingcustomer == true) //failed to reach customer?
      {
      customer.customerrating = 0;
      }
                  
                  
                  
                  
             //     print(customer.customerrating)
                  
                  if(customer.customerrating > 5)
                    customer.customerrating = 5;
                  else if(customer.customerrating < 0)
                    customer.customerrating = 0;
                  
                  //for testing:
               //   customer.customerrating = 0;
                  
              //    print(customer.customerrating)
                  
                  if(customer.customerrating <= 2)
                    customer.unhappyreviewcount = customer.unhappyreviewcount + 1;
                  
                  
                  
                  if(customer.unhappyreviewcount >= 1)
                  customer.overallgoodrating = false;
                  
                  
                  
    //calculate the average time elapsed so far:    
                  
    customer.sumoftimeelapsed = customer.sumoftimeelapsed + customer.timeelapsed;
    customer.numberoftimeelapsedinputs = customer.numberoftimeelapsedinputs + 1; 
    customer.averagetimeelapsed = customer.sumoftimeelapsed / customer.numberoftimeelapsedinputs
                  
                  // print(customer.sumoftimeelapsed)
                  // print(customer.numberoftimeelapsedinputs)
                  // print(customer.averagetimeelapsed)
       
       
                  //broadcast:
                if(this.broadcastservedcustomer == false && customer.refreshing == false && customer.failedreachingcustomer == false)
                  {
                  this.broadcastmyevent = 2; //broad cast this event!
                  listlog.insertloginformation()
                  this.broadcastmyevent = -1;
                  
                  this.broadcastservedcustomer = true
                    
                  }
                  
                if(this.broadcastfailedcustomer == false && customer.refreshing == false && customer.failedreachingcustomer == true)
                  {
                  this.broadcastmyevent = 6; //broad cast this event!
                  listlog.insertloginformation()
                  this.broadcastmyevent = -1;
                    
                  this.broadcastfailedcustomer = true;
                  }
                  
        //     print("i delivered the customer to its final location!")
        //       print("my driver id:")
        //       print(this.id)
        // //      print(customer.currentcustomer)
        //     print("-----")
          
        
                }
              
    
    
              customer.beingserved = false;
              this.servingcustomer = false;
              this.scannedservecustomer = false;
              
              customer.timeelapsed = 0;
    
              //----
              listd.driverwithgoodmood = false;
              listd.driverwithmatchingmusic = false; //These will be checked again to see if they are true for the next customer but are set to false by default       
              listd.driverthatisbusy = false;
    
              listd.knownclosestdistance = 100000000;
    
    
              listd.prioritizedistance = true;
              //----
              
              this.closestdistance = false;
    
              this.horizontal = true
              this.status = "AVAILABLE"; //resting or available
    
    
    
        if(this.broadcastsimulationrefresh == false && customer.refreshing == true)
          {
          this.broadcastmyevent = 5; //broad cast this event!
          listlog.insertloginformation()
          this.broadcastmyevent = -1;
                  
          this.broadcastsimulationrefresh = true
            
            
           customer.unhappyreviewcount = 0;
           customer.overallgoodrating = true;
          }
    
              
          listc.customermovethroughlist() //calllist()
          
              
          this.currentRide = null;
      
              
            if(customer.firsttestcustomer == true)
              customer.firsttestcustomer = false //''
              
              
              
            if(customer.refreshing == true)
              {
                customer.refreshing = false
                simulation.simulationspeed = simulation.simulationspeedstore
                
    customer.sumoftimeelapsed = 0;
  
    customer.numberoftimeelapsedinputs = 0;
  
   customer.averagetimeelapsed = 0;
                
                
                print("refreshing done!")
              }
            
              
              this.status = "RESTING"
              
         this.busymultiply = 1; //reset the multipler so that the car fuel is not extra 
    
    
    
  }
  
  movedriver()
  {
  //  print(this.capacity)
  //  print(listd.prioritizedistance)
    
    if(this.status === "BUSY" && this.capable == true)
      {
        
        if(this.closestdistance == false && listd.prioritizedistance == true && customer.firsttestcustomer == false) //this makes it so that the driver that is considering serving the customer checks to see if they are closest to the customer. The driver only checks once, and if they are not closest, they give the closest driver time to serve the customer. If the customer is still not served, they temporarily tell all the drivers in the list that distance does not to be prioritized for this customer since it is taking a very long time for the closest driver to become available.
          {
          listd.prioritizedistance = false; //do not need to prioritize distance for next time if checked
          this.donotservecustomer()
            
          return;
          }
        
        
        //check for a good mood (and then later check for favourite music matching)
        
        this.correctedpos = false //allow the driver to correct their position again next time they slip off the grid
        
        if(this.goodmood == false)
          {
            //serve customer
            if(listd.driverwithgoodmood == false)
            this.servecustomer() //least ideal conditions but necessary to serve (can not overtake)
            
            //do not serve
            if(listd.driverwithgoodmood == true)
            this.donotservecustomer()
            
          }
        if(this.goodmood == true)
          {
            
            if(this.musicmatch == true) //
            this.servecustomer() //most ideal conditions! (will include driver #1) (driver may overtake)
                
            
            if(this.musicmatch == false)
              {
                
                if(listd.driverwithmatchingmusic == true)
                this.donotservecustomer()
                
                if(listd.driverwithmatchingmusic == false)
                this.servecustomer() //driver may overtake 
                
              }
            
            
        
        }
        
        
      }
    else if (this.status == "BUSY" && this.capable == false)
      {
        // print("im tired")
        // print(this.capable)
        // print(this.capacity)
        
        this.donotservecustomer()
      
      }
    
    
    
    
    
    
    
    if(this.status === "CARRYING") //has customer (fully committed)
      {
        
        customer.displayfinallocation()
        customer.beingserved = true;
        customer.beingcarried = true;
        this.servingcustomer = true;
        
        this.athome = false;
        
       stroke('orange')
        

    line(this.location.x,this.location.y,customer.finallocation.fx,this.location.y)
    line(customer.finallocation.fx,customer.finallocation.fy,customer.finallocation.fx,this.location.y)
        
        
        if(this.horizontal == true)
          {
          //  print("trying to go horizontal!")
        if(this.location.x < customer.finallocation.fx)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.finallocation.fx)
      this.location.x = this.location.x - this.speed
            
           //check within a range to prevent driver from being stuck!
      if(this.location.x > customer.finallocation.fx - 10 && this.location.x < customer.finallocation.fx || this.location.x < customer.finallocation.fx + 10 && this.location.x > customer.finallocation.fx) 
        {
          this.location.x = customer.finallocation.fx
        }
            
            
      if(this.location.x == customer.finallocation.fx)
         this.horizontal = false
            
            
          }
        
        else if (this.horizontal == false)
          {
           // print("trying to go vertical!")
            
        if(this.location.y < customer.finallocation.fy)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.finallocation.fy)
      this.location.y = this.location.y - this.speed
            
             //check within a range to prevent driver from being stuck!
      if(this.location.y > customer.finallocation.fy - 10 && this.location.y < customer.finallocation.fy || this.location.y < customer.finallocation.fy + 10 && this.location.y > customer.finallocation.fy) 
        {
          this.location.y = customer.finallocation.fy
        }
      
            
            
          if(this.location.y == customer.finallocation.fy)
            {
              customer.beingcarried = false;
              this.finishservingcustomer()
            }
            
          }
        
      }
    
    
    if(this.status === "AVAILABLE") //slowly return home (if needed), look for future customers 
      {
        if(this.location.x == this.homelocation.x && this.location.y == this.homelocation.y)
         this.athome = true;
        else
          this.athome = false;
        
     if(this.horizontal == true)
       {
         if(this.location.x < this.homelocation.x)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > this.homelocation.x)
        this.location.x = this.location.x - this.speed/2
         
         if(this.location.x == this.homelocation.x)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < this.homelocation.y)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > this.homelocation.y)
       this.location.y = this.location.y - this.speed/2
          
          if(this.location.y == this.homelocation.y)
          this.horizontal = true
        }
        
        
          if(listd.currentdriver.currentRide !== listc.final && customer.currentcustomer !== null) //helps to assign and reassign a customer
           { 
    listd.currentdriver.assignRide(customer,500*this.busymultiply) 
             
           }
        
        
        
        
      }
  
    
  }
  
  alternatemovedriver()
  {
      if(this.status === "RESTING") //slowly return home and wait
      {
        this.currentRide = null
        this.servingcustomer = false;
        
        if(this.location.x == this.homelocation.x && this.location.y == this.homelocation.y)
         this.athome = true;
        else
          this.athome = false;
        
        
        // for(let i = 0; i<=13; i++)
        //   {
            //print(this.location.y)
            
            // if(this.location.y != 40*i && this.correctedpos == false)
            //   {
            //     print("running")
            //     this.location.y = 40*i
            //     this.correctedpos = true;
            //     this.horizontal = true
            //   }
          // }
 
      
    if(this.location.y != 40*i && this.correctedpos == false) //lock onto the road if slipping off
      {
//     //    print("i am here")
      
       if(this.location.y > 40*1 && this.location.y < 40*3)
        this.location.y = 40*2
        
        if(this.location.y > 40*3 && this.location.y < 40*5)
        this.location.y = 40*4
        
        
        if(this.location.y > 40*5 && this.location.y < 40*7)
        this.location.y = 40*6
        
        
        if(this.location.y > 40*7 && this.location.y < 40*9)
        this.location.y = 40*8
        
        if(this.location.y > 40*9 && this.location.y < 40*11)
        this.location.y = 40*10
        
        this.correctedpos = true;
        this.horizontal = true;
        
//     //    print(this.id)
//    // this.location.y = 40*2
        
      }
            

  
        
        
     if(this.horizontal == true)
       {
         if(this.location.x < this.homelocation.x)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > this.homelocation.x)
        this.location.x = this.location.x - this.speed/2
         
         
      //check within a range to prevent driver from being stuck!
      if(this.location.x > this.homelocation.x - 10 && this.location.x < this.homelocation.x || this.location.x < this.homelocation.x + 10 && this.location.x > this.homelocation.x) 
        {
          this.location.x = this.homelocation.x
        }
         
         
         if(this.location.x == this.homelocation.x)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < this.homelocation.y)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > this.homelocation.y)
       this.location.y = this.location.y - this.speed/2
          
          //check within a range to prevent driver from being stuck!
      if(this.location.y > this.homelocation.y - 10 && this.location.y < this.homelocation.y || this.location.y < this.homelocation.y + 10 && this.location.y > this.homelocation.y) 
        {
          this.location.y = this.homelocation.y
        }
          
          
          
          if(this.location.y == this.homelocation.y && this.location.x == this.homelocation.x)
            {
          this.horizontal = true
              
              
              
              
        //  this.busymultiply = 1; //reset the multipler so that the car fuel is not extra (moved to when the driver finishes serving the customer)
              
              
       //   this.correctedpos = false //allow the driver to correct their position again next time they slip off the grid (moved to when the driver is busy)
            }
        }
        
        
      

        
        
        
        
        
        
        
      }
    
    
  }

  update() { //
    
    //update relating to customer:
    
        if(customer.timeelapsed > 2000 && customer.firsttestcustomer == false && customer.refreshing == false && customer.beingcarried == false && this.servingcustomer == true && customer.beingserved == true) //did the drivers fail to reach the customer?
      {
        
        customer.failedreachingcustomer = true;
        
      
        
        if(customer.failedreachingcustomer == true)
          {
         //   print("failedreachingcustomer is now true!")
           customer.customerrating = 0;
            
           listd.currentdriver.assignRide(customer,500*this.busymultiply)
            
           this.status = "BUSY"
           this.savedxlocation = this.location.x
           this.savedylocation = this.location.y
               
           this.location.x = customer.location.x
           this.location.y = customer.location.y
            
          this.horizontal = true
          this.status = "CARRYING"
              
          customer.displayfinallocation()
               
               
            this.location.x = customer.finallocation.fx
            this.location.y = customer.finallocation.fy
               
         ///  print("ran teleport")
           this.finishservingcustomer()
            
            
          this.location.x = this.savedxlocation
          this.location.y = this.savedylocation
               
          this.savedxlocation = -1;
          this.savedylocation = -1;
            
            
          customer.failedreachingcustomer = false
          customer.timeelapsed = 0;
          }
        

      }
    
    
    
    
    //update relating to itself and others:
    
    if(this.capable == true && this.goodmood == true && this.musicmatch == true)
    this.mostidealconditions = true
    else
    this.mostidealconditions = false
    
    // print(this.id)
    // print(this.mostidealconditions)
    
    
      
    if (this.status === "BUSY") 
    {
     this.busyTimer = this.busyTimer - (this.speed-1)/random(0.9,1.5); //()  1.2 or random(0.9,1.5)
      
    // this.busyTimer = this.busyTimer - (this.speed-1)*6; //() FOR TESTING
      
    //  print(this.busyTimer)
      
      if (this.busyTimer <= 0) 
      {
        
         if(this.broadcastexpire == false && customer.refreshing == false)
          {
          this.broadcastmyevent = 4; //broad cast this event!
          listlog.insertloginformation()
          this.broadcastmyevent = -1;
                  
          this.broadcastexpire = true
          }
        
        // print("--------------")
        // print("I need more fuel! (busyTimer ran out)")
        // print("My driver Id:")
        // print(this.id)
        // print("--------------")
        
        this.horizontal = true
        this.status = "RESTING" //or resting or available
        
        customer.beingserved = false;
        this.servingcustomer = false;
        
        this.currentRide = null;
        
        this.busymultiply = this.busymultiply + 1 //since the car is running low on fuel, the driver can add more than before 
        listd.prioritizedistance = false
        
      }
      
      
    }
    
    if(this.status === "RESTING")
      {
        
        this.broadcastmyevent = -1; //makes sure the value is at -1 (broadcasting nothing)
        //reset all broadcast booleans
        this.broadcastconnection = false;
        this.broadcastexpire = false; 
        this.broadcastoverride = false;
        this.broadcastservedcustomer = false; 
        this.broadcastsimulationrefresh = false;
        this.broadcastfailedcustomer = false;
        
        if(this.mostidealconditions == true && this.checkeddriver1once == false)
          {
    listd.driverwithgoodmood = false; 
    listd.driverwithmatchingmusic = false; 
       this.checkeddriver1once = true;
          }
        
        
        
        if(this.location.x == this.homelocation.x && this.location.y == this.homelocation.y)
          {
         this.restingTimer = this.restingTimer - (this.speed-1);
            text(this.restingTimer,this.homelocation.x,this.homelocation.y + 20)
          }
        
        if(this.restingTimer <= 0)
          {

            this.status = "AVAILABLE"
            this.restingTimer = round(random(90,500));
            
            this.checkeddriver1once = false;
            
          } 
        
      }
  }

  display() 
  {
    if(this.status === "AVAILABLE")
      fill("green")
    if(this.status === "BUSY")
      fill("red")
    if(this.status === "CARRYING")
      fill("orange")
    if(this.status === "RESTING")
      fill("black")
    
    ellipse(this.location.x, this.location.y, 22);
    fill(0);
    textSize(10);
    textAlign(CENTER);
    
    fill(100,100,100)
    text(this.id,this.location.x,this.location.y + 3)
    
   //// textSize(8)
   //// text(this.capable,this.location.x,this.location.y)
    
    if(this.capable == false)
      {
    fill(200,0,0)
    text(this.capable,this.location.x+20,this.location.y)
      }
    if(this.goodmood == false)
      {
    fill(200,151,0)
    text(this.goodmood,this.location.x+20,this.location.y + 5)
      }
    if(this.musicmatch == false)
      {
        fill(0,200,0)
        text(this.musicmatch,this.location.x+20,this.location.y + 10)
      }
    
    if(this.closestdistance == true && listd.prioritizedistance == true)
      {
      fill(255, 159, 0)
      text("!",this.location.x-10,this.location.y-5)
        //shows closest
   //   print(this.id)
      }
    if(this.closestdistance == true && listd.prioritizeddistance == false)
      {
      fill(255, 159, 0)
      text("?",this.location.x-10,this.location.y-5)
        
      }
    
    
    
    if(this.id == 1 && this.canholdanycustomer == true) //mark the main driver
      {
      fill(200,100,30)
   // fill(255,255,0)
    text("''",this.location.x+0,this.location.y-5)
      }
    
    
    fill(100,100,100)
    
  }
  
  drawhome() //draw a dot that represents home
  {
    
    if(this.drawnhome == false)
      {
    if(this.id == 1)
      {
        this.homelocation.x = 40
        this.homelocation.y = 80
      }
    else if(this.id == 2)
      {
        this.homelocation.x = 40*12
        this.homelocation.y = 80
      }
    else if(this.id > 2) //3 or above!
      {
        this.homelocation.x = 40*round(random(1,12))
        this.homelocation.y = 40*round(random(2,9))
      }
        
      this.drawnhome = true;
      }
    
    
    fill(255,0,0)
    circle(this.homelocation.x,this.homelocation.y,5) //40 each
    fill(0)
    textSize(10)
   // text("Home",28,65)
    
    if(this.id == 1)
    text("Home",this.homelocation.x-12,this.homelocation.y - 15)
    else
    text("Home",this.homelocation.x-3,this.homelocation.y - 15)
    
    
    text(this.id,this.homelocation.x-12+30,this.homelocation.y - 15)
    
    if(this.id == 2 || this.id == 1)
      text("'",this.homelocation.x-12+36,this.homelocation.y - 15)
    
  }
  
  starthome() //start the driver at home
  {
    
    if(this.id == 1)
      {
        this.location.x = 40 //40*1
        this.location.y = 80 //40*2
      }
    else if(this.id == 2)
      {
        this.location.x = 40*12
        this.location.y = 80
      }
    else if (this.id > 2) // 3 or above!
      {
        this.location.x = this.homelocation.x
        this.location.y = this.homelocation.y
      }
    
    
    
  }
  
  
  updatespeed()
  {
  //  print(this.location.x)
   // print(this.speed)
    
    for(i = 0; i<=10; i++)
      {
        if(simulation.simulationspeed == i) //numbers!
          this.speed = i+1;
      }
  }
  
  
  checkforcapability() //checks to see if the driver is currently capable of serving the customer (capacity)
  {
    //  print("driver id:")
    //  print(this.id)
    // print("this.capacity")
    //  print(this.capacity)
   // // print("am i capable of dealing with the customer?")
   // // print(this.capable)
    
//     print("driver with a good mood and available")
//     print(listd.driverwithgoodmood)
//     print("driver with matching music and available?")
//     print(listd.driverwithmatchingmusic)
    
//     print("00000000000000000000000")
    
//     print("I!)")
    
    
  if(customer.lastcustomerserved == false) //not the last one on the list? (prevents null)
  {
        
    //  print("i am running this")
    
    if(customer.refreshing == false)
   {
     
    if(this.capacity >= customer.currentcustomerdisplaynode.capacityneeded)
      {
        this.capable = true;
      }
    else if(this.capacity < customer.currentcustomerdisplaynode.capacityneeded)
      {
        this.capable = false;
      }
     
   }
    
    
    
  }
    
    
  if(customer.lastcustomerserved == true && customer.doneservingallcustomer == false) //is the last customer being served?
    {
      
      if(customer.refreshing == false)
      {
        
      if(this.capacity >= customer.currentcustomer.capacityneeded)
      {
        this.capable = true;
      }
    else if(this.capacity < customer.currentcustomer.capacityneeded)
      {
        this.capable = false;
      }
        
        
      }
      
    }
 
    
    
    if(customer.refreshing == true)
      {
        this.capable = true
      }
    
    
    
  }
  
  
  
  
  
  
  
  
  checkforidealconditions() //amenities will be considered here! ////(distance could also be considered here!)
  {
    ////----(special amenities prints for debugging)------:
    
  //
//      print("driver id:")
//      print(this.id)
    
//       print("good mood set? (0 will make false, 1 will make true)")
//       print(this.goodmoodset)
    
//     print("good mood?")
//     print(this.goodmood)
     
//      print("favourite music? (0 is all, 1,2,3,4 or 5 is other)") 
//      print(this.favouritemusic)
    
   // print(listd.drivergoingvertical)
    
    
//      print("does my favourite music match with customer? (or does my favourite music equal 0)")
//      print(this.musicmatch)
    
    
    
    
    
    //----(distance prints for debugging)------:
    
    // print("do i have the closest distance to the customer?")
    // print(this.id)
    // print(this.closestdistance)
    
//     print("what is my distance from the customer?")
//     print(this.distance)
    
//   //  print("have we found a close distance? as a whole")
//   //  print(listd.foundclosestdistance)
    
//    print("what is the closest distance? as a whole")
//    print(listd.knownclosestdistance)
    
    // //FOR TESTING:
   // if(this.status == "RESTING")
   //   this.status = "AVAILABLE"
    
    // if(this.closestdistance == true && listd.foundclosestdistance == true)
    //   {
    //     print("closest driver:")
    //     print(this.id)  
    //   }
    
    
  //----distance------:
    
     this.distancex = customer.location.x - this.location.x
     if(this.distancex <= 0)
     this.distancex = this.distancex*-1
    
   // print(this.distancex)
    
  this.distancey = customer.location.y - this.location.y
    if(this.distancey <= 0)
     this.distancey = this.distancey*-1
    
  //  print(this.distancey)
    this.distance = this.distancex + this.distancey
    
    if(this.distance <= 0) //only allow distance to be positive!
      this.distance = this.distance*-1
    
    
    
    if(this.distance < listd.knownclosestdistance && this.capable == true && this.athome == true && customer.beingserved == false && this.status != "AVAILABLE")
      {
        listd.knownclosestdistance = this.distance
      }
    
    if(this.distance == listd.knownclosestdistance)
      {
        listd.closestdrivermarkid = this.id
      }
    
    
    if(this.id == listd.closestdrivermarkid)
      this.closestdistance = true;
    else
      this.closestdistance = false;
    
    
    
    
    //----special amenities------:
    
    if(this.goodmoodset == 0)
      {
      this.goodmood = false
      }
    else if(this.goodmoodset == 1)
      {
      this.goodmood = true
        
      if(this.status == "AVAILABLE" && this.capable == true)
        {
        if(this.closestdistance == true && listd.prioritizedistance == true || listd.prioritizedistance == false)
        listd.driverwithgoodmood = true;
        }
      }
    
    
    
    if(customer.lastcustomerserved == false) //not the last one on the list? (prevents null)
  {
        
    //  print("i am running this")
     if(customer.refreshing == false)
      {
    
    if(this.favouritemusic == customer.currentcustomerdisplaynode.favouritemusicwanted || this.favouritemusic == 0)
      {
        this.musicmatch = true;
        
        if(this.status == "AVAILABLE" && this.capable == true)
          {
            
        if(this.closestdistance == true && listd.prioritizedistance == true || listd.prioritizedistance == false)
        listd.driverwithmatchingmusic = true;
            
          }
      }
        
        
   else
      {
        this.musicmatch = false;
      }
        
        
        
      }
     
    
  }
    
    
    
  if(customer.lastcustomerserved == true && customer.doneservingallcustomers == false) //is the last customer being served?
    {
      
      if(customer.refreshing == false)
      {
        
      if(this.favouritemusic == customer.currentcustomer.favouritemusicwanted || this.favouritemusic == 0)
      {
        this.musicmatch = true;
        
        if(this.status == "AVAILABLE" && this.capable == true)
        listd.driverwithmatchingmusic = true;
      }
   else
      {
        this.musicmatch = false;
      }
        
      }
  
      
    }
    
    
  }
  
  
  
  
  
}
































