//--------EVENTNODES----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



class EventNode
{ //links or Nodes
  constructor(id,eventtype,driverid,customerrequestid,customertimeelapsed,driveramountrecorded,drivergoodmoodrecorded,overallgoodratingsrecorded,drivermusicmatchrecorded,driverdistancerecorded,simulationspeedrecorded,customeraveragetimeelapsed,customerratingrecorded,y) 
  { //request id
    this.id = id; //id
    this.next = null;
    
    this.eventtype = eventtype; //0 means that it is the head of the list and marks the start of a series of customers. 1 means that a driver sees a customer and matched with a customer, 2 means that the customer was served! 4 means that the match expired between the driver and the customer, while 3 means that the match was overridden by a driver with better conditions. (5 means simulation refresh, 6 means failed to reach customer)
    
    this.overallgoodratingsrecorded = overallgoodratingsrecorded;
    
    
    this.driverid = driverid;
    this.driveramountrecorded = driveramountrecorded;
    this.drivergoodmoodrecorded = drivergoodmoodrecorded;
    this.drivermusicmatchrecorded = drivermusicmatchrecorded;
    this.driverdistancerecorded = driverdistancerecorded;
    
    this.customerrequestid = customerrequestid;
    this.customertimeelapsed = customertimeelapsed;
    this.customerratingrecorded = customerratingrecorded;
    
    this.customeraveragetimeelapsed = customeraveragetimeelapsed;
    
    this.simulationspeedrecorded = simulationspeedrecorded;
    
    this.y = y;
  }
  
  firstevent() //let the first stay constant
  {
    
    if(this.id == 1) //marks the start of the list
    this.eventtype = 0
    
  }
  
  create() //creates an event by drawing the event under the "Log information" (Helps to temporarily display small information about the nodes on the screen as they are being created)
  {
    //the node with eventtype == 0 will mark the head of the list and will not be edited
    
 //    if(this.eventtype == 0 && this.id == 1)  //text("Log information:",625,20)
 //      {
 //  //  fill(0)
 //  //  textSize(5) //hi!
 // //   text("hi!",625-80,20+20-20) // For testing: 545,40 (625-80,20+20) 
 //      }
    
     if(this.eventtype == 1)  //text("Log information:",625,20)
       {
     textSize(12)
     text("Driver __ is serving request # __",625-3,this.y) //40 for y
     text(this.driverid,600-23,this.y-2) //38 for y
     text(this.customerrequestid,600-23+124,this.y-2) //38 for y
       }
    
    if(this.eventtype == 2) 
      {  
       textSize(12)
      text("Driver __ has served request # __!",625+3,this.y) 
      text(this.driverid,600-23,this.y-2) 
      text(this.customerrequestid,600-23+124+8,this.y-2) 
      }
    
    if(this.eventtype == 3)
      { 
     textSize(12)
     text("Driver __ is now serving instead",625+3,this.y) 
     text(this.driverid,600-16,this.y-2)  
      }
    
    
    if(this.eventtype == 4) //driver busyTimer ran out (driver is backing off of the request)
      {
    textSize(12)
     text("The match expired with driver __",625+3,this.y) 
     text(this.driverid,600+107,this.y-2) 
      }
    
    if(this.eventtype == 5)
      {
    textSize(12)
     text("Refreshed! (Good ratings? ____)",625+3,this.y) 
     text(this.overallgoodratingsrecorded,600-23+122,this.y)
      }
    if(this.eventtype == 6) //customer was waiting too long (customer decided to stop requesting)
      {
    textSize(12)
     text("Failed to serve customer #__!", 625+3,this.y)
     text(this.customerrequestid,600-23+124-4,this.y-2)   
      }
    
  //  print(this.y)
    if(listlog.Y == 1)
      {
        this.y = -40;
      }
    
    if(this.y >= 170)
      {
      //  print("start")
        listlog.Y = 1;
        listlog.savedY = 40;
        fill(50)
        rect(685,110,300,170)
     //   listlog.cleardisplay()
     //   listlog.startcleardisplay = true;
      }
    
    
  }
  
  
}