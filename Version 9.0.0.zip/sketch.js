//--------SKETCH----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

let simulation;
let driver
let customer


//(Request nodes and event nodes are created inside of the linked lists)
//let request (or node)
//let event

function setup() 
{
 // print("Hello World!")
  createCanvas(720, 400); //13 squares X, 10 squares Y    //720 is 520+200
  simulation = new SimulationController(width, height);
  
  frameRate(60)
//  print(frameCount)
  
  customer = new Customer()
  
  listc = new LinkedList() //linked list instance for requests (customers)
  listd = new LinkedList() //linked list instance for drivers
  
  listlog = new LinkedList() //linked list used for logging information
  
  
  for(i = 1; i<=4; i++) //4 for default, then turns into 8 after refresh
    {
  listc.insertcustomer()
   }
  
  
    for(i = 1; i<=2; i++) //2 for default
     {
       listd.insertdriver()
     }
  
  
  //insert the head of the log to allow more logs to be added!
  listlog.insertloginformation() //1
  
  
  listd.displaylist()  //prints out the linked lists and shows the data inside
  listc.displaylist()
  
  
  customer.setcustomerstart() //prints out the information for the customer and starts the customer at the first point
  
 // listlog.displaylist()

  
}

function draw() 
{
  background(245);
  simulation.display();
  
  listd.drivercommands() //keeps drivers updated by scrolling through the drivers and allowing them to update
  listlog.eventnodecommands()
  
  
  customer.display()
  customer.update()
  customer.managelist()
  
  
  for(let i = 0; i<=13; i++)
    {
      fill('pink')
      text(i,i*39+5,10)
    }
  
  for(let i = 1; i<=10; i++)
    {
      fill('pink')
      text(i,5,i*40)
    }
  
 // print(listd.driverthatisbusy)
 // print(customer.beingserved)
 //  print(customer.currentcustomer)
 // print(customer.firsttestcustomer)
  
  //print(customer.lastcustomerserved)
//  print(customer.doneservingallcustomers)
  
   // print("node being displayed:")
   // print(customer.currentcustomerdisplaynode)
  
//   print("currentnode")
//   print(customer.currentcustomer)
  
 //  print(listd.driverwithgoodmood)
 // print(listd.driverwithmatchingmusic)
  
 // print(listlog)
  
 // print(listd.foundclosestdistance)
  
}

function keyPressed()
{
  if(keyIsPressed == true)
    {
    
    if(key === "0")
      {
    print("printing full log information:") 
      listlog.displaylist()
      }
      
      
    }
  
  
  
}

function mouseReleased() //for testing and more!
{
  print("Hello!")
  print("-----")
  
  if(mouseX > 530 && customer.refreshing == false)
    {
  simulation.updatespeed();
 // listlog.displaylist()
    }
  
  
  ////----------------------
  ////create drivers!
  
//   if(mouseX < 530 && customer.refreshing == false)
//   {
  
//     listd.size = 2
    
//   for(i = 2; i<=30; i++) 
//           {
//        listd.remove(i)
//           }
        
//         listd.amountofdrivers = 1; 
        
//         for(i = 3; i<=9; i++) //
//          {
//           listd.insertdriver()
//           listd.amountofdrivers = listd.amountofdrivers + 1;
//         }
    
//   }
  
  
  ////----------------------
  
  
  
  //if(keyPressed == 0)
  //  print("0")
  
 // print(simulation.simulationspeed)
 // print(listd.currentdriver)
  //print(listd.currentdriver.speed)
  
   // print(listd.driverwithgoodmood)
 // print(listd.driverwithmatchingmusic)
  
  //print(listd.currentdriver.capacity)
  
  
  //test the search function for the node search
 // listc.search(4)
//  listd.search(2)
  
  
  
 // customer.refreshing = true
  
//  listc.displaylist()
 // listd.displaylist()
  
  print("-----")
}