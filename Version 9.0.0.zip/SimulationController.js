//--------SIMULATION CONTROLLER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------


class SimulationController 
{
  constructor(width, height) 
  {
    this.map = new TownMap(width, height);
    
    this.simulationspeed = 1; //1 is default
    this.simulationspeedstore = 0; //will store the simulation speed for refreshing quicker!
  }

  display() 
  {
    this.map.drawGrid();
    this.renderHUD();
  }
  
  updatespeed()
  {
    //updated on drivers too (the effect takes place on drivers)!
    
    this.simulationspeed = this.simulationspeed +1; //(this.simulationspeed++)
    
    if(this.simulationspeed >= 10) //not 10 (>= 10)
      this.simulationspeed = 1
    
  }
  

  renderHUD() 
  {
    fill(0);
    textSize(14);
    textAlign(LEFT);
    text("Ride-Share Simulation", 20, 25);
  }
}





