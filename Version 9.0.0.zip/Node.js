//--------NODE----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class Node 
{ //links or Nodes
  constructor(id) 
  { //request id
    this.id = id; //id
    this.next = null;
    this.pos = createVector(round(random(0,13)),round(random(0,10)))
    
    this.finalpos = createVector(round(random(0,13)),round(random(0,10)))
    
    this.capacityneedednormaldistribution = round(random(1,15)) //allows the capacity needed to be more normally distrubuted, with higher capacities needed being less common. (poisson curve)
    
    this.favouritemusicwanted = round(random(1,5)) //the customer will prefer listening to music that matches with the driver's taste in music (if the driver's taste in music is 0, then the customer will always be happy)
    
    if(this.capacityneedednormaldistribution <= 5)
      this.capacityneeded = 1 //1,2,3,4,5
    if(this.capacityneedednormaldistribution > 5 && this.capacityneedednormaldistribution <= 9)
      this.capacityneeded = 2 //6,7,8,9
    if(this.capacityneedednormaldistribution > 9 && this.capacityneedednormaldistribution <= 12)
      this.capacityneeded = 3 //10,11,12
    if(this.capacityneedednormaldistribution > 12 && this.capacityneedednormaldistribution <= 14)
      this.capacityneeded = 4 //13,14
    if(this.capacityneedednormaldistribution == 15)
      this.capacityneeded = 5 //15
    
     //the capacity needed shows how many passengers will enter the cars! the capacity of the car will need to be above or equal to this number to accept the request
    
    //FOR TESTING:
   //   print("d")
   // this.capacityneeded = 5 //(max)
   //  this.capacityneeded = 1 //(min)
    
  }
  
  
}