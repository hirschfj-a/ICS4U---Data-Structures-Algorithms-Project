class Driver {
  constructor(id, location, x, y, speed, capacity = 4, amenities = []) {
  //  this.location = location;
    this.location = createVector(x,y)
    this.horizontal = true;
    this.speed = 2; //1 or 2 is default
    
    
    
    this.id = id;
    this.capacity = capacity;
    this.amenities = amenities;

    this.status = "AVAILABLE"; //AVAILABLE,BUSY,CARRYING
    this.currentRide = null;
    this.busyTimer = 0;
  }

  assignRide(request, duration) {
    this.status = "BUSY";
    this.currentRide = request;
   // this.currentRide = customer;
    this.busyTimer = duration;
    
    if(this.location.x == 40*1 && this.location.y == 40*2) //if at home?
      {
    this.horizontal = true
 //   print("i see the customer")
      }
  }
  
  movedriver()
  {
    if(this.status === "BUSY")
      {
        if(this.horizontal == true)
          {
        if(this.location.x < customer.location.x)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.location.x)
      this.location.x = this.location.x - this.speed
            
      if(this.location.x == customer.location.x)
         this.horizontal = false
       
          }
        
        else if (this.horizontal == false)
          {
            
        if(this.location.y < customer.location.y)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.location.y)
      this.location.y = this.location.y - this.speed
      
            
            
          if(this.location.y == customer.location.y)
            {
        //      print("i made it to the customer!")
              this.horizontal = true
              this.status = "CARRYING"
              
              customer.displayfinallocation()
              
          //    this.status = "AVAILABLE";
          //    this.currentRide = null; 
            }
            
          }
        
      }
    
    if(this.status === "CARRYING") //has customer
      {
        
        customer.displayfinallocation()
        
       stroke('magenta')
        

line(this.location.x,this.location.y,customer.finallocation.fx,this.location.y)
         line(customer.finallocation.fx,customer.finallocation.fy,customer.finallocation.fx,this.location.y)
        
        
        if(this.horizontal == true)
          {
        if(this.location.x < customer.finallocation.fx)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.finallocation.fx)
      this.location.x = this.location.x - this.speed
            
      if(this.location.x == customer.finallocation.fx)
         this.horizontal = false
            
            
             
       
          }
        
        else if (this.horizontal == false)
          {
            
        if(this.location.y < customer.finallocation.fy)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.finallocation.fy)
      this.location.y = this.location.y - this.speed
      
            
            
          if(this.location.y == customer.finallocation.fy)
            {
      //      print("i delivered the customer to its final location!")
              this.horizontal = true
              this.status = "AVAILABLE";
              
              customer.calllist()
      
              this.currentRide = null; 
            }
            
            
            //cuy
          
            
          }
        
      }
    
    
    if(this.status === "AVAILABLE") //slowly return home, look for future customers
      {
     if(this.horizontal == true)
       {
         if(this.location.x < 40*1)
        this.location.x = this.location.x + this.speed
         if(this.location.x > 40*1)
        this.location.x = this.location.x - this.speed
         
         if(this.location.x == 40*1)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < 40*2)
       this.location.y = this.location.y + this.speed
          if(this.location.y > 40*2)
       this.location.y = this.location.y - this.speed
          
          if(this.location.y == 40*2)
          this.horizontal = true
        }
        
      }
    
  }

  update() {
    if (this.status === "BUSY") {
      this.busyTimer--;
      if (this.busyTimer <= 0) {
        this.status = "AVAILABLE";
        this.currentRide = null;
      }
    }
  }

  display() {
 //   fill(this.status === "AVAILABLE" ? "green" : "red");
    if(this.status === "AVAILABLE")
      fill("green")
    if(this.status === "BUSY")
      fill("red")
    if(this.status === "CARRYING")
      fill("orange")
    
    ellipse(this.location.x, this.location.y, 22);
    fill(0);
    textSize(10);
    textAlign(CENTER);
    text(this.id, this.location.x, this.location.y - 15);
  }
  
  drawhome() //draw a dot that represents home
  {
    fill(255,0,0)
    circle(40,80,5) //40 each
    fill(0)
    textSize(10)
    text("Home",28,65)
  }
  
  starthome() //start the driver at home
  {
    this.location.x = 40 //40*1
    this.location.y = 80 //40*2
    
    
    
  }
}