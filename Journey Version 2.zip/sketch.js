let simulation;
let driver
let customer
//let request

function setup() {
 // print("Hello World!")
  createCanvas(520, 400); //13 squares X, 10 squares Y
  simulation = new SimulationController(width, height);
  
  frameRate(60)
  
//  print(frameCount)
  
  driver = new Driver()
  customer = new Customer()
  
  list1 = new LinkedList()
  
  
  for(i = 1; i<=4; i++)
    {
  list1.insert()
    }
  
  list1.displaylist()
  driver.starthome()
  customer.setcustomerstart()
 // list1.remove(2) //remove a link for testing //FIX
 // list1.displaylist()
  
  if(driver.status === "AVAILABLE")
  driver.assignRide(customer)
  
}

function draw() {
  background(245);
  simulation.update();
  simulation.display();
  
  driver.drawhome()
  driver.display()
  driver.update()
  
  customer.display()
  
  driver.movedriver()
}