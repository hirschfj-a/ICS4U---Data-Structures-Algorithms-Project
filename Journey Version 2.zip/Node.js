class Node { //links or Nodes
  constructor(id) { //request id
    this.id = id; //id
    this.next = null;
    this.pos = createVector(round(random(0,13)),round(random(0,10)))
    
    this.finalpos = createVector(round(random(0,13)),round(random(0,10)))
    
  }
}