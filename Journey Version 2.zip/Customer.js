class Customer {
  constructor(id, location, x, y, fx, fy, passengers = 1, amenitiesRequired = []) {
   // this.location = location;
    this.location = createVector(x,y)
    this.finallocation = createVector(fx,fy)
    
    this.number = createVector(x,y) //---> is used for knowing where the customer is! 
    this.currentcustomer = null //current delivery, used as a curr when the driver follows the linked list!
    
    
    
    this.id = id;
    this.passengers = passengers;
    this.amenitiesRequired = amenitiesRequired;

    this.requestTime = millis();
  }

  display() {
    fill(100,100,255); //blue
    rectMode(CENTER);
    rect(this.location.x, this.location.y, 18, 18);

    fill(255);
    textSize(10);
    textAlign(CENTER);
    text(this.id, this.location.x, this.location.y - 14);
  }
  
  displayfinallocation()
  {
    fill(0,0,200) 
    rectMode(CENTER);
    rect(this.finallocation.fx, this.finallocation.fy, 10,10)
    
   //// print(this.finallocation.fx)
    
    this.location.x = driver.location.x
    this.location.y = driver.location.y
    
  }
  
  setcustomerstart()
  {
    this.location.x = 40*10
    this.location.y = 40*8
    
    this.finallocation.fx = 40*5
    this.finallocation.fy = 40*4
  }
  
  calllist()
  {
    list1.movethroughlist()
  }
}