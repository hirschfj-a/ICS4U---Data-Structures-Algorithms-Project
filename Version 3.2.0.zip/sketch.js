//--------SKETCH----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

let simulation;
let driver
let customer
//let request

function setup() 
{
 // print("Hello World!")
  createCanvas(520, 400); //13 squares X, 10 squares Y
  simulation = new SimulationController(width, height);
  
  frameRate(60)
//  print(frameCount)
  
  customer = new Customer()
  
 // driver = new Driver()
   //driver.starthome()
  
  
  listc = new LinkedList() //linked list instance for customers
  listd = new LinkedList() //linked list instance for drivers
  
  
  for(i = 1; i<=4; i++)
    {
  listc.insertcustomer()
   }
  
  for(i = 1; i<=2; i++)
   {
     listd.insertdriver()
   }
  
  listd.displaylist()  //prints out the linked lists and shows the data inside
  listc.displaylist()
  customer.setcustomerstart() //prints out the information for the customer and starts the customer at the first point

  
}

function draw() 
{
  background(245);
  simulation.update();
  simulation.display();
  
  listd.drivercommands() //keeps drivers updated by scrolling through the drivers and allowing them to update
  
  customer.display()
  customer.managelist()
  
  
  for(let i = 0; i<=13; i++)
    {
      fill('pink')
      text(i,i*39+5,10)
    }
  
  for(let i = 1; i<=10; i++)
    {
      fill('pink')
      text(i,5,i*40)
    }
  
 // print(customer.beingserved)
 //  print(customer.currentcustomer)
 // print(customer.firsttestcustomer)
  
  //print(customer.lastcustomerserved)
//  print(customer.doneservingallcustomers)
  
}

function mouseReleased() //for testing!
{
  print("Hello!")
  listc.search(4)
  
  listd.search(2)
  
  
  
 // customer.refreshing = true
  
//  listc.displaylist()
 // listd.displaylist()
  
  print("-----")
}






































































