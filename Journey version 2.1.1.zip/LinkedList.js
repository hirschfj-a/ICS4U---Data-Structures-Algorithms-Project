class LinkedList 
{
  constructor() 
  {
    this.head = null;
    this.size = 1;
    
    this.final = null;
  }

  insert(data) 
  { //ADD LINKS
    print("hi!")
    let node = new Node(this.size++); //this.size++?
      if(this.head === null)
        {
          this.head = node;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          customer.currentcustomer = this.head; //START LIST BY SHOWING FIRST DELIVERY NEEDED (in linked list)!
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = node;
          
        }
  }

  delete(data) //remove(n) OR delete(data)
  {
    //students implement
  }

  search(predicate) 
  {
    // STUDENTS IMPLEMENT
  }

  traverse(callback) 
  {
    // STUDENTS IMPLEMENT
  }
  
  
  displaylist()
  {
    print("-----------------------------")
      print("NOW DISPLAYING:")
      print("head:")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null && curr.next !== null)
        {
          print(curr)
        //  print(this.id)
    //      text(this.id,100,this.id*50)
          curr = curr.next;
          
        }
    
    //runs when the while loop is false (last one):
       print(curr)
       this.final = curr
       curr = curr.next;
       
    print("final:")
     print(this.final)
      
      
      print("-----------------------------")
    
  }
  
  
  movethroughlist()
  {
   // print("test")
    
    while(driver.currentRide !== null && driver.status == "AVAILABLE")
      {
        customer.number.x = customer.currentcustomer.pos.x  //position information from linked list
        customer.number.y = customer.currentcustomer.pos.y
        
        customer.finalnumber.fx = customer.currentcustomer.finalpos.x
        customer.finalnumber.fy = customer.currentcustomer.finalpos.y
        
  
        
   //     print("new position for delivery: (Uses linked list):")
  //      print("start pos:")
        print("Current customer information:")
        print(customer.currentcustomer)
    //    print(driver.currentRide)
      //  print("start")
        print(customer.number.x)
        print(customer.number.y)
      //  print("end")
     //   print(customer.finalnumber.fx)
      //  print(customer.finalnumber.fy)
        
        
      
        
        
    for(let i = 0; i<=13; i++)
    {
    if(customer.number.x == i)
    customer.location.x = 40*i
      
    if(customer.number.y == i)
    customer.location.y = 40*i
      
      
    if(customer.finalnumber.fx == i)
    customer.finallocation.fx = 40*i
      
    if(customer.finalnumber.fy == i)
    customer.finallocation.fy = 40*i
      
    }
        
      //  print("next customer (preview):")
      //  print(customer.currentcustomer.next)
  
 // if(customer.currentcustomer.next !== null && driver.currentRide === null)
 // if(customer.currentcustomer !== null)
 //   {
  if(customer.currentcustomer !== this.final)
    {
  customer.currentcustomer = customer.currentcustomer.next;
    }
  else
    {
      customer.currentcustomer = null
    }
  //  }
//  else
//  {
// driver.assignRide(null)
//  customer.currentcustomer = null
//  }
   
 // if(customer.currentcustomer === this.final)
 //  driver.assignRide(customer,500)
        
        
//  if(customer.currentcustomer !== null)
 //   {
   driver.assignRide(customer,500) //will go to the customer! (500 or 90 for testing)
 //   }
  

        
        
        
        
    //    print(customer.currentcustomer)
    //    print(customer.currentcustomer.next)
        
     //   print(driver.assignRide)
        
 
      }
    
    print("-----------------------------")
    
    
  }
  
  
//   remove(n) //remove(n) OR delete(data)
//   {
//      print("-----------------")
//       print("REMOVING Link #:")
//       print(n) //data or 'n'
//       print("-----------------")
      
//       let prev = null;
//       let curr = this.head;
//       while(curr.id !== n)//keep moving if not target link
//         {
//           prev = curr;
//           curr = curr.next;
//           if(curr === null) //reached end of list?
//             {
//               return; //end
//             }
//         }
//       prev.next = curr.next //(removes link)
//   }
  
  
  
  
}