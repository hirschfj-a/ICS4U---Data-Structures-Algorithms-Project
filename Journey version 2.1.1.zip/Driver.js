class Driver {
  constructor(id, location, x, y, speed, capacity = 4, amenities = []) {
  //  this.location = location;
    this.location = createVector(x,y)
    this.horizontal = true;
    this.speed = 2; //1 or 2 is default
    
   // this.lastcustomerserved = false;
    
    
    
    this.id = id;
    this.capacity = capacity;
    this.amenities = amenities;

    this.status = "AVAILABLE"; //AVAILABLE,BUSY,CARRYING
    this.currentRide = null;
    this.busyTimer = 0;
    this.restingTimer = 500; //500 or 90
  }

  assignRide(request, duration) { //assignRide(request,duration) optional
    this.status = "BUSY";
    this.currentRide = request;
   // this.currentRide = customer;
    this.busyTimer = duration;
    
    if(this.location.x == 40*1 && this.location.y == 40*2) //if at home?
      {
    this.horizontal = true
  //  print("i see the customer")
      }
  }
  
  movedriver()
  {
    if(this.status === "BUSY")
      {
        stroke('magenta')
        
   line(this.location.x,this.location.y,customer.location.x,this.location.y)
   line(customer.location.x,customer.location.y,customer.location.x,this.location.y)
        
        if(this.horizontal == true)
          {
        if(this.location.x < customer.location.x)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.location.x)
      this.location.x = this.location.x - this.speed
            
      if(this.location.x == customer.location.x)
         this.horizontal = false
       
          }
        
        else if (this.horizontal == false)
          {
            
        if(this.location.y < customer.location.y)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.location.y)
      this.location.y = this.location.y - this.speed
      
            
            
          if(this.location.y == customer.location.y)
            {
      //        print("i made it to the customer!")
              this.horizontal = true
              this.status = "CARRYING"
              
              customer.displayfinallocation()
              
          //    this.status = "AVAILABLE";
          //    this.currentRide = null; 
            }
            
          }
        
      }
    
    if(this.status === "CARRYING") //has customer
      {
        
        customer.displayfinallocation()
        
       stroke('orange')
        

    line(this.location.x,this.location.y,customer.finallocation.fx,this.location.y)
    line(customer.finallocation.fx,customer.finallocation.fy,customer.finallocation.fx,this.location.y)
        
        
        if(this.horizontal == true)
          {
        if(this.location.x < customer.finallocation.fx)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.finallocation.fx)
      this.location.x = this.location.x - this.speed
            
      if(this.location.x == customer.finallocation.fx)
         this.horizontal = false
            
            
             
       
          }
        
        else if (this.horizontal == false)
          {
            
        if(this.location.y < customer.finallocation.fy)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.finallocation.fy)
      this.location.y = this.location.y - this.speed
      
            
            
          if(this.location.y == customer.finallocation.fy)
            {
            print("i delivered the customer to its final location!")
        //      print(customer.currentcustomer)
            print("-----")
              
          //    if(customer.currentcustomer === list1.final && this.lastcustomerserved === false)
         //       {
                  
           //       driver.assignRide(customer,500)
                  
                 // this.lastcustomerserved = true;
               //   print("I finished serving all customers in the linked list!")
           //     }
              
              this.horizontal = true
              this.status = "AVAILABLE"; //resting or available
              
          //    customer.calllist()
              
           //   this.currentRide = null; 
              this.status = "RESTING"
            }
            
            
            
            //cuy
          
            
          }
        
      }
    
    
    if(this.status === "AVAILABLE") //slowly return home, look for future customers
      {
     if(this.horizontal == true)
       {
         if(this.location.x < 40*1)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > 40*1)
        this.location.x = this.location.x - this.speed/2
         
         if(this.location.x == 40*1)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < 40*2)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > 40*2)
       this.location.y = this.location.y - this.speed/2
          
          if(this.location.y == 40*2)
          this.horizontal = true
        }
        
     //   if(this.lastcustomerserved == true && customer.currentcustomer !== list1.final)
      //        {
       //         this.status = "AVAILABLE"
       //         this.currentRide = null;
       //         print("I finished serving all customers in the linked list!")
       //       }
      //  if(this.lastcustomerserved == false && customer.currentcustomer !== list1.final)
      //    {
            customer.calllist()
            this.currentRide = null;
      //    }
    //    
    //    if(this.lastcustomerserved == false && customer.currentcustomer === list1.final)
    //      {
    //        customer.calllist()
    //        this.currentRide = null;
   //       }
        
     //    if(customer.currentcustomer === list1.final && this.lastcustomerserved === false)
      //         {
                  
        //          driver.assignRide(customer,500)
                  
         //         this.lastcustomerserved = true;
              //    print("I finished serving all customers in the linked list!")
          //      }
        
          
    //    if(driver.currentRide === null && customer.currentcustomer !== null) //ready for new customer?
    //      {
      //      print("this is running")
    //        driver.assignRide(customer,500);
    //      }
        
   // if(driver.currentRide === null && customer.currentcustomer !== null && customer.currentcustomer === list1.final)
  //    {
   //   driver.assignRide(customer,500)
   //   }
        
     if(driver.currentRide === null && customer.currentcustomer !== null) //ensures the driver does not lose their customer
      {
      driver.assignRide(customer,500)
      }
        
      
        
    //    if(driver.currentRide !== null && customer.currentcustomer !== null) //or next maybe
    //      {
       //     print("i am running")
    //        driver.assignRide(customer,500);
     //     }
        
     //   if(driver.currentRide === null && )
        
    //    print(customer.currentcustomer)
     //   if(driver.currentRide === null && customer)
        
      }
    
    
     if(this.status === "RESTING") //slowly return home and wait
      {
        
     if(this.horizontal == true)
       {
         if(this.location.x < 40*1)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > 40*1)
        this.location.x = this.location.x - this.speed/2
         
         if(this.location.x == 40*1)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < 40*2)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > 40*2)
       this.location.y = this.location.y - this.speed/2
          
          if(this.location.y == 40*2)
          this.horizontal = true
        }
        
        
      }
    
  }

  update() {
    if (this.status === "BUSY") 
    {
      this.busyTimer--; //this.busyTimer = this.busyTimer - 1
      if (this.busyTimer <= 0) 
      {
        this.status = "RESTING";
        this.currentRide = null;    
      }
    }
    
    if(this.status === "RESTING")
      {
        if(this.location.x == 40*1 && this.location.y == 40*2)
          {
         this.restingTimer--; //this.restingTimer = this.restingTimer - 1;
          text(this.restingTimer,40,100)
          }
        
        if(this.restingTimer <= 0)
          {
            this.status = "AVAILABLE"
            this.restingTimer = round(random(90,500));
            
           // customer.calllist()
  
          } 
     //   print(this.restingTimer)
        
      }
  }

  display() {
 //   fill(this.status === "AVAILABLE" ? "green" : "red");
    if(this.status === "AVAILABLE")
      fill("green")
    if(this.status === "BUSY")
      fill("red")
    if(this.status === "CARRYING")
      fill("orange")
    if(this.status === "RESTING")
      fill("black")
    
    ellipse(this.location.x, this.location.y, 22);
    fill(0);
    textSize(10);
    textAlign(CENTER);
    text(this.id, this.location.x, this.location.y - 15);
  }
  
  drawhome() //draw a dot that represents home
  {
    fill(255,0,0)
    circle(40,80,5) //40 each
    fill(0)
    textSize(10)
    text("Home",28,65)
  }
  
  starthome() //start the driver at home
  {
    this.location.x = 40 //40*1
    this.location.y = 80 //40*2
    
    
    
  }
}