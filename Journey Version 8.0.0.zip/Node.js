//--------NODE----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class Node 
{ //links or Nodes
  constructor(id) 
  { //request id
    this.id = id; //id
    this.next = null;
   // this.purpose = round(random(0,1)); //0 makes the node represent a customer while 1 makes the node represent a driver
    this.pos = createVector(round(random(0,13)),round(random(0,10)))
    
    this.finalpos = createVector(round(random(0,13)),round(random(0,10)))
    
    
    this.capacityneeded = round(random(1,5))
    //the capacity needed shows how many passengers will enter the cars! the capacity of the car will need to be above or equal to this number to accept the request
    this.favouritemusicwanted = round(random(1,5)) //the customer will prefer listening to music that matches with the driver's taste in music (if the driver's taste in music is 0, then the customer will always be happy)
    
    
    //FOR TESTING:
   // this.capacityneeded = 5 //(max)
    //  this.capacityneeded = 1 //(min)
    
  }
  
  
}