//--------TOWNMAP----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class TownMap 
{
  constructor(width, height, gridSize = 40) 
  {
    this.width = width; //520
    this.height = height; //400
    this.gridSize = gridSize;
  }

  getRandomLocation() {
    return {
      x: floor(random(this.width / this.gridSize)) * this.gridSize + this.gridSize / 2,
      y: floor(random(this.height / this.gridSize)) * this.gridSize + this.gridSize / 2
    };
  }

  getDistance(loc1, loc2) {
    return dist(loc1.x, loc1.y, loc2.x, loc2.y);
  }

  drawGrid() {
    stroke(220);
    // for (let x = 0; x < this.width; x += this.gridSize) {
    //   line(x, 0, x, this.height);
    // }
    // for (let y = 0; y < this.height; y += this.gridSize) {
    //   line(0, y, this.width, y);
    // }
    
    
    for (let x = 0; x < 520; x += this.gridSize) {
      line(x, 0, x, 400);
    }
    for (let y = 0; y < 400; y += this.gridSize) {
      line(0, y, 520, y);
    }
    
    stroke(500);
    line(520,0,520,400)
    
    fill(50)
    rect(530+100,200,200,400)
    
    fill(0)
    textSize(15) //hi!
    text("Log information:",625,20)
    
    
    fill(0)
    rect(530+100,530,200,400)
    
    textSize(14)
    text("Simulation Speed:", 520+100,400-45)
    textSize(11)
    text("(Click to increase!)", 520+100,400-30)
    textSize(19)
    text(simulation.simulationspeed, 520+100,400-10)
    
    
  //   textSize(13)
  //   text("Capacities:",520+100,400-145)
  // //  text(listd.currentdriver.capacity)
    
    textSize(11)
    fill(100,0,0)
    text("Capacity Needed for Customer:",520+95,400-85-20)
    textSize(15)
    
    if(customer.firsttestcustomer == false && customer.refreshing == false && customer.lastcustomerserved == false)
    text(customer.currentcustomerdisplaynode.capacityneeded,520+185,400-83-20)
    
    if(customer.lastcustomerserved == true && customer.refreshing == false)
    text(customer.currentcustomer.capacityneeded,520+185,400-83-20)
    
    
    
    
    
    textSize(11)
    fill(0,100,0)
    text("Favourite Music of Customer:",520+90,400-85)
    
    textSize(15)
    if(customer.firsttestcustomer == false && customer.refreshing == false && customer.lastcustomerserved == false)
      text(customer.currentcustomerdisplaynode.favouritemusicwanted,520+185,400-83)
    
    if(customer.lastcustomerserved == true && customer.refreshing == false)
      text(customer.currentcustomer.favouritemusicwanted,520+185,400-83)
    
    fill(0)
    line(530,205,720,205)
    line(530,205+75,720,205+75)
    
    textSize(11)
    fill(0)
    text("Legend:",520+35,220)
    textSize(10)
    fill(100,0,0)
    text("(Capacity met? --> red!)",520+67,220+20)
    fill(200,151,0)
    text("(Good mood? --> yellow!)",520+70,220+35)
    fill(0,100,0)
    text("(Favourite music match? --> green!)",520+93,220+50)
    
    
    
    
  }
}
