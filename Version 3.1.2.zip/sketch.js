//--------SKETCH----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

let simulation;
let driver
let customer
//let request

function setup() {
 // print("Hello World!")
  createCanvas(520, 400); //13 squares X, 10 squares Y
  simulation = new SimulationController(width, height);
  
  frameRate(60)
  
//  print(frameCount)
  
  customer = new Customer()
  
  listc = new LinkedListc() //the linked list for the customers will operate differently from the linked list for the drivers
  listd = new LinkedListd()
  
  
  for(i = 1; i<=4; i++)
    {
  listc.insert()
    }
  
  for(i = 1; i<=2; i++)
    {
      listd.insert()
    }
  
  listc.displaylist()
 // driver.starthome()
  customer.setcustomerstart()

  
}

function draw() {
  background(245);
  simulation.update();
  simulation.display();
  
  listd.drivercommands()
  
  customer.display()
  customer.managelist()
  
  
  for(let i = 0; i<=13; i++)
    {
      fill('pink')
      text(i,i*39+5,10)
    }
  
  for(let i = 1; i<=10; i++)
    {
      fill('pink')
      text(i,5,i*40)
    }
  
 // print(customer.beingserved)
 //  print(customer.currentcustomer)
 // print(customer.firsttestcustomer)
  
  //print(customer.lastcustomerserved)
//  print(customer.doneservingallcustomers)
  
}

function mouseReleased() //for testing!
{
  print("Hello!")
  listc.search(4)
 // customer.refreshing = true
  
//  listc.displaylist()
 // listd.displaylist()
  
  
}


























//--------CUSTOMER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------







class Customer {
  constructor(id, location, x, y, fx, fy, passengers = 1, amenitiesRequired = []) {
   // this.location = location;
    this.location = createVector(x,y)
    this.finallocation = createVector(fx,fy)
    
    this.number = createVector(x,y) //---> is used for knowing where the customer is! 
    this.finalnumber = createVector(fx,fy)
    this.currentcustomer = null //current delivery, used as a curr when the driver follows the linked list!
    this.currentcustomerdisplay = 0 //current delivery for display on the square!
    
    this.firsttestcustomer = true;
    this.beingserved = false;
    
    this.lastcustomerserved = false; //OR LASTCUSTOMERSERVING
    this.doneservingallcustomers = false;
    
    this.refreshing = false;
    
    
    
    
    this.id = id;
    this.passengers = passengers;
    this.amenitiesRequired = amenitiesRequired;

    this.requestTime = millis();
  }

  display() 
  {
    if(this.currentcustomer !== null && this.doneservingallcustomers == false && this.lastcustomerserved == false && this.currentcustomer != listc.final.id && this.currentcustomer != listc.head.id && this.firsttestcustomer != true) // other customers are being served!
      {
   //     print("22222") (print("qwoibnfgbgoiu"))
         this.currentcustomerdisplay = this.currentcustomer.id - 1
      }

    if(this.doneservingallcustomers == false && this.lastcustomerserved == true) //last customer is being served!
      {
        this.currentcustomerdisplay = listc.final.id
      }
    if(this.firsttestcustomer == true) //the test customer is being served!
      {
        this.currentcustomerdisplay = 0
      }
    if(this.currentcustomer == listc.head.id && this.doneservingallcustomers == false) //the head of the list is being served!
      {
        this.currentcustomerdisplay = 1
      }
    
    
    if(this.currentcustomerdisplay == 0 && this.firsttestcustomer != true) //check to make sure the head of the list is being served
      {
        this.currentcustomerdisplay = 1
      }
    
    
  //  else if(this.currentcustomer == listc.head.id)
   //   {
   //    this.currentcustomerdisplay = listc.head.id
   //   }
   // else if(this.currentcustomer == listc.final.id && this.doneservingallcustomers == false)
   //   {
    //    print("qwoibnfgbgoiu")
   //      this.currentcustomerdisplay = listc.final.id
   //   }
    
 //   print(this.currentcustomer)
    
    if(this.beingserved == true && this.doneservingallcustomers != true && this.refreshing == false)
      { 
        
    if(this.firsttestcustomer == true)
    fill(100,100,100) //gray
        
    if(this.currentcustomerdisplay == listc.head.id && this.firsttestcustomer == false)
    fill(100,100,185) //dark blue
        
        
    if(this.firsttestcustomer == false && this.currentcustomerdisplay != listc.head.id)
    fill(100,100,255); //blue
        
        
    rectMode(CENTER);
    rect(this.location.x, this.location.y, 18, 18);

    fill(255);
    textSize(10);
    textAlign(CENTER);
   // text(this.id, this.location.x, this.location.y - 14);
    text(this.currentcustomerdisplay, this.location.x, this.location.y + 3);
      }
  }
  
  displayfinallocation()
  {
    if(this.beingserved == true && this.doneservingallcustomers == false && this.refreshing == false)
      {
    fill(0,0,200) 
    rectMode(CENTER);
    rect(this.finallocation.fx, this.finallocation.fy, 10,10)
    
   //// print(this.finallocation.fx)
    
    this.location.x = listd.currentdriver.location.x
    this.location.y = listd.currentdriver.location.y
      }
    
  }
  
  setcustomerstart()
  {
    print("----------------------------- ")
    print("Current customer information:")
    print("(This is the first test customer!)")
    print("10")
    print("8")
    
    this.location.x = 40*10
    this.location.y = 40*8
    
    this.finallocation.fx = 40*5
    this.finallocation.fy = 40*4
    
    
  //  print("next customer (preview):")
//    print("Node {id: 1} (Will be the head link of the linked list for customers!)")
    
    print("----------------------------- ")
  }
  
  calllist()
  {
    listc.movethroughlist()
  }
  
  managelist()
  {
    if(this.doneservingallcustomers == true && this.lastcustomerserved == true)
      {
        
        listc.size = 2
        
        for(i = 2; i<=8; i++)
          {
       listc.remove(i)
          }
        
        for(i = 2; i<=8; i++)
         {
          listc.insert()
        }
        
        
        print("refreshed all customers! (kept the head of the list!)")
        listc.displaylist()
        
        
        this.currentcustomer = listc.head //restart back at the head and refresh!
        
     //    print("Current customer information:")
     //   print("(This is the head of the list!)")
     //   print(customer.currentcustomer)
     //   print(customer.number.x)
     //   print(customer.number.y)
     //   print("-----------------------------")
        
     //   this.currentcustomerdisplay = 1
        this.doneservingallcustomers = false
        this.lastcustomerserved = false
        
        this.refreshing = true;
      }
    
    
    if(this.refreshing == true)
      {
     //   print("refreshing...")
        
        
        rect(420,350,900,800) //width and height to cover the screen while it refreshes
        fill(0);
    textSize(14);
    textAlign(LEFT)
        text("Ride-Share Simulation", 20, 25);
        text("(refreshing...)",20+200, 25)
        
      //  text("Ride-Share Simulation", 20, 25)
       // this.refreshing = false  //refreshing will be disabled by the driver!
      }
    
  }
}









































//--------DRIVER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------




class Driver {
  constructor(id, location, x, y, speed, capacity, amenities = []) {
  //  this.location = location;
    this.location = { x: x, y: y };
    this.horizontal = true;
    this.speed = 2; //1 or 2 is default
    
    
    this.homelocation = createVector(x,y)
    this.onlyonce = true //runs commands only once in the beginning
    
    this.servingcustomer = false;
    
   // this.lastcustomerserved = false;
    
    
    
    this.id = id;
    this.next = null;
    
    
    this.capacity = capacity
    
    
    this.amenities = amenities;

    this.status = "AVAILABLE"; //AVAILABLE,BUSY,CARRYING,RESTING
    this.currentRide = null;
    this.busyTimer = 0;
    this.restingTimer = 500; //500 or 90
  }

  assignRide(request, duration) { //assignRide(request,duration) optional
    this.status = "BUSY";
    this.currentRide = request;
   // this.currentRide = customer;
    this.busyTimer = duration;
    
    if(this.location.x == 40*1 && this.location.y == 40*2) //if at home?
      {
    this.horizontal = true
  //  print("i see the customer")
      }
  }
  
  movedriver()
  {
  //  print(this.capacity)
    
    if(this.status === "BUSY")
      {
        stroke('magenta')
        
        customer.beingserved = true;
        this.servingcustomer = true;
        
      //  print("hello")
        
   line(this.location.x,this.location.y,customer.location.x,this.location.y)
   line(customer.location.x,customer.location.y,customer.location.x,this.location.y)
        
        if(this.horizontal == true)
          {
        if(this.location.x < customer.location.x)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.location.x)
      this.location.x = this.location.x - this.speed
            
      if(this.location.x == customer.location.x)
         this.horizontal = false
       
          }
        
        else if (this.horizontal == false)
          {
            
        if(this.location.y < customer.location.y)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.location.y)
      this.location.y = this.location.y - this.speed
      
            
            
          if(this.location.y == customer.location.y)
            {
      //        print("i made it to the customer!")
              this.horizontal = true
              this.status = "CARRYING"
              
              customer.displayfinallocation()
              
          //    this.status = "AVAILABLE";
          //    this.currentRide = null; 
            }
            
          }
        
      }
    
    if(this.status === "CARRYING") //has customer
      {
        
        customer.displayfinallocation()
        customer.beingserved = true;
        this.servingcustomer = true;
        
       stroke('orange')
        

    line(this.location.x,this.location.y,customer.finallocation.fx,this.location.y)
    line(customer.finallocation.fx,customer.finallocation.fy,customer.finallocation.fx,this.location.y)
        
        
        if(this.horizontal == true)
          {
        if(this.location.x < customer.finallocation.fx)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.finallocation.fx)
      this.location.x = this.location.x - this.speed
            
      if(this.location.x == customer.finallocation.fx)
         this.horizontal = false
            
            
             
       
          }
        
        else if (this.horizontal == false)
          {
            
        if(this.location.y < customer.finallocation.fy)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.finallocation.fy)
      this.location.y = this.location.y - this.speed
      
            
            
          if(this.location.y == customer.finallocation.fy)
            {
              if(customer.refreshing == false)
                {
            print("i delivered the customer to its final location!")
              print("my driver id:")
              print(this.id)
        //      print(customer.currentcustomer)
            print("-----")
                }
              
              customer.beingserved = false;
              this.servingcustomer = false;
              
              this.horizontal = true
              this.status = "AVAILABLE"; //resting or available
              
           customer.calllist()
          this.currentRide = null;
      
              
            if(customer.firsttestcustomer == true)
              customer.firsttestcustomer = false //''
              
            if(customer.refreshing == true)
              {
                customer.refreshing = false
                print("refreshing done!")
              }
            
              
              this.status = "RESTING"
              
            }
            
          }
        
      }
    
    
    if(this.status === "AVAILABLE") //slowly return home, look for future customers
      {
        
     if(this.horizontal == true)
       {
         if(this.location.x < this.homelocation.x)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > this.homelocation.x)
        this.location.x = this.location.x - this.speed/2
         
         if(this.location.x == this.homelocation.x)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < this.homelocation.y)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > this.homelocation.y)
       this.location.y = this.location.y - this.speed/2
          
          if(this.location.y == this.homelocation.y)
          this.horizontal = true
        }
        

        
        if(listd.currentdriver.currentRide !== listc.final && customer.currentcustomer !== null)
          {
        listd.currentdriver.assignRide(customer,500)
          }
        
        
        
      }
  
    
  }
  
  alternatemovedriver()
  {
      if(this.status === "RESTING") //slowly return home and wait
      {
        this.currentRide = null
        this.servingcustomer = false;
        
     if(this.horizontal == true)
       {
         if(this.location.x < this.homelocation.x)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > this.homelocation.x)
        this.location.x = this.location.x - this.speed/2
         
         if(this.location.x == this.homelocation.x)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < this.homelocation.y)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > this.homelocation.y)
       this.location.y = this.location.y - this.speed/2
          
          if(this.location.y == this.homelocation.y)
          this.horizontal = true
        }
        
        
      }
    
    
  }

  update() {
    if (this.status === "BUSY") 
    {
      this.busyTimer--; //this.busyTimer = this.busyTimer - 1
      if (this.busyTimer <= 0) 
      {
        this.status = "RESTING";
        this.currentRide = null;    
      }
    }
    
    if(this.status === "RESTING")
      {
        if(this.location.x == this.homelocation.x && this.location.y == this.homelocation.y)
          {
         this.restingTimer--; //this.restingTimer = this.restingTimer - 1;
            text(this.restingTimer,this.homelocation.x,this.homelocation.y + 20)
          }
        
        if(this.restingTimer <= 0)
          {
            this.status = "AVAILABLE"
            this.restingTimer = round(random(90,500));
            
          } 
        
      }
  }

  display() {
 //   fill(this.status === "AVAILABLE" ? "green" : "red");
    if(this.status === "AVAILABLE")
      fill("green")
    if(this.status === "BUSY")
      fill("red")
    if(this.status === "CARRYING")
      fill("orange")
    if(this.status === "RESTING")
      fill("black")
    
    ellipse(this.location.x, this.location.y, 22);
    fill(0);
    textSize(10);
    textAlign(CENTER);
  //  text(this.id, this.location.x, this.location.y - 15);
    
    fill(100,100,100)
    text(this.id,this.location.x,this.location.y + 3)
  }
  
  drawhome() //draw a dot that represents home
  {
    if(this.id == 1)
      {
        this.homelocation.x = 40
        this.homelocation.y = 80
      }
    else if(this.id == 2)
      {
        this.homelocation.x = 40*12
        this.homelocation.y = 80
      }
    
    
    fill(255,0,0)
    circle(this.homelocation.x,this.homelocation.y,5) //40 each
    fill(0)
    textSize(10)
   // text("Home",28,65)
    
    if(this.id == 1)
    text("Home",this.homelocation.x-12,this.homelocation.y - 15)
    else
    text("Home",this.homelocation.x-3,this.homelocation.y - 15)
    
    text(this.id,this.homelocation.x-12+30,this.homelocation.y - 15)
  }
  
  starthome() //start the driver at home
  {
   // this.location.x = 40 //40*1
  //  this.location.y = 80 //40*2
    
    if(this.id == 1)
      {
        this.location.x = 40
        this.location.y = 80
      }
    else if(this.id == 2)
      {
        this.location.x = 40*12
        this.location.y = 80
      }
    
    
    
  }
}



































//--------LINKEDLISTS----------------------------------------------------------------------------------------------------------------------------------------------------------------------------




class LinkedListc 
{
  constructor() 
  {
    this.head = null;
    this.size = 1;
    
    this.final = null;
  }

  insert(data) 
  { //ADD LINKS
    print("hi!")
    let node = new Node(this.size++); //this.size++? (The node (or information of the customer) exists in the list!)
      if(this.head === null)
        {
          this.head = node;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          customer.currentcustomer = this.head; //START LIST BY SHOWING FIRST DELIVERY NEEDED (in linked list)!
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = node;
          
        }
  }

 // delete(data) //remove(n) OR delete(data)
 // {
    //students implement
 // }

 // search(predicate) 
 // {
    // STUDENTS IMPLEMENT
  search(predicate)
   {
  let curr = this.head;
  while (curr !== null) 
  {
  //  print(curr)
    if (predicate == curr.id) 
    {
      print(curr)
      return curr;
    }
    curr = curr.next;
  }
  print("Could not find that node!")
     
  return null;
}

//  }

  //traverse(callback) 
 // {
    // STUDENTS IMPLEMENT
 // }
  
  
  displaylist()
  {
    print("-----------------------------")
      print("NOW DISPLAYING (FOR CUSTOMERS!):")
      print("head: (stays constant)")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null && curr.next !== null)
        {
          print(curr)
        //  print(this.id)
    //      text(this.id,100,this.id*50)
          curr = curr.next;
          
        }
    
    //runs when the while loop is false (last one):
       print(curr)
       this.final = curr
       curr = curr.next;
       
    print("final:")
     print(this.final)
      
      
      print("-----------------------------")
    
  }
  
  
  movethroughlist()
  {
   // print("test")
    
    while(listd.currentdriver.currentRide !== null && listd.currentdriver.status == "AVAILABLE")
      {
    //    print(listd.currentdriver.currentRide)
     //   print(listd.currentdriver.status)
        
        customer.number.x = customer.currentcustomer.pos.x  //position information from linked list
        customer.number.y = customer.currentcustomer.pos.y
        
        customer.finalnumber.fx = customer.currentcustomer.finalpos.x
        customer.finalnumber.fy = customer.currentcustomer.finalpos.y
        
  
        print("Current customer information:")
        if(customer.currentcustomer == this.head)
        print("(This is the head of the list!)")
        
        print(customer.currentcustomer)
        
        print(customer.number.x)
        print(customer.number.y)
        
        
      
        
        
    for(let i = 0; i<=13; i++)
    {
    if(customer.number.x == i)
    customer.location.x = 40*i
      
    if(customer.number.y == i)
    customer.location.y = 40*i
      
      
    if(customer.finalnumber.fx == i)
    customer.finallocation.fx = 40*i
      
    if(customer.finalnumber.fy == i)
    customer.finallocation.fy = 40*i
      
    }
    
    if(customer.lastcustomerserved == true) //FINAL CUSTOMER FULLY SERVED
      {
        customer.doneservingallcustomers = true;
        
        print("----------------------------- ")
        print("i delivered the final customer to its final location!!!")
        print("my driver id:")
        print(listd.currentdriver.id)
        print("----------------------------- ")
      }
        

   if(customer.currentcustomer !== this.final)
   {
  //  remove(customer.currentcustomer)
  customer.currentcustomer = customer.currentcustomer.next;
    }
  else
   {
     if(customer.lastcustomerserved == true)
      customer.currentcustomer = null
     
     
     if(customer.lastcustomerserved == false)
       {
       customer.currentcustomer = customer.currentcustomer //do nothing
       customer.lastcustomerserved = true
       }
   }
        
   listd.currentdriver.assignRide(customer,500) //will go to the customer! (500 or 90 for testing)
 
      }
    
   print("-----------------------------")
    
    
  }
  
  
   remove(n) //remove(n) OR delete(data)
   {
      print("-----------------")
       print("REMOVING Link #:")
       print(n) //data or 'n'
       print("-----------------")
      
       let prev = null;
       let curr = this.head;
       while(curr.id !== n)//keep moving if not target link
         {
           prev = curr;
           curr = curr.next;
           if(curr === null) //reached end of list?
             {
               return; //end
             }
         }
       prev.next = curr.next //(removes link)
   }
  
  
  
  
}













class LinkedListd
  {
    
      constructor() 
  {
    this.head = null;
    this.size = 1;
    this.currentdriver = null; //let this be "curr" for the whole list
    
    this.final = null;
    
    this.doneassigningfirstcapacity = false;
    this.doneassigningallcapacities = false;
  }

  insert(data) 
  { //ADD LINKS
  //  print("hi!")
     driver = new Driver(this.size++); //this.size++? (Creates a copy of driver!)
      if(this.head === null)
        {
          this.head = driver;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = driver;
          
        }
  }
    
    
    
     displaylist()
  {
    print("-----------------------------")
      print("NOW DISPLAYING (FOR DRIVERS!):")
      print("head:")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null && curr.next !== null)
        {
          print(curr)
          curr = curr.next;
          
        }
    
    //runs when the while loop is false (last one):
       print(curr)
       this.final = curr
       curr = curr.next;
       
    print("final:")
     print(this.final)
      
      
      print("-----------------------------")
    
  }
    
    drivercommands()
  {
   this.currentdriver = this.head; //act as curr
    
    while(this.currentdriver !== null)
        {
          if(this.currentdriver.onlyonce == true)
            {
              this.currentdriver.starthome()
              this.currentdriver.onlyonce = false
            }
          
       //   FIX! (FIXED!)
          
          if(this.doneassigningfirstcapacity == false)
            {
              this.currentdriver.capacity = 3;
        
              this.doneassigningfirstcapacity = true
            }
          if(this.currentdriver.capacity != 3 && this.doneassigningfirstcapacity == true)
            {
              this.currentdriver.capacity = 5;
              
              this.doneassigningallcapacities = true //all customers will now have a driver that exists for them (a driver can now hold any capacity)
            }
          
         // if(this.doneassigningallcapacities == true)
          //any driver that exists can have any capacity now
          
          
          
          this.currentdriver.drawhome()
          this.currentdriver.display()
          this.currentdriver.update()
          
          this.currentdriver.alternatemovedriver()
          
          if(customer.beingserved == true && this.currentdriver.servingcustomer == true)
            {
          this.currentdriver.movedriver()
         //    print(this.currentdriver.id)
          //   print("i am running")
            }
          
          if(customer.beingserved == false && this.currentdriver.servingcustomer == false && this.currentdriver.status === "AVAILABLE") //only allows one driver at a time 
            {
          customer.beingserved = true
          this.currentdriver.servingcustomer = true
         //     print("i ran")
            }
          
          this.currentdriver = this.currentdriver.next; //cycles through each driver
          
          
       //   print("this is running")
          
        }
          
    
  }
  
      
    
    
    
    
    
    
  }






//--------NODE----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



class Node { //links or Nodes
  constructor(id) { //request id
    this.id = id; //id
    this.next = null;
    this.pos = createVector(round(random(0,13)),round(random(0,10)))
    
    this.finalpos = createVector(round(random(0,13)),round(random(0,10)))
    
    
    this.capacityneeded = round(random(1,5))
    //the capacity needed shows how many passengers will enter the cars! the capacity of the car will need to be above or equal to this number to accept the request
    
  }
}


























//--------SIMULATION CONTROLLER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------



class SimulationController {
  constructor(width, height) {
    this.map = new TownMap(width, height);

    // STUDENTS MUST INITIALIZE THESE AS LINKED LISTS
    this.availableDrivers = null;
    this.pendingRequests = null;
    this.activeMatches = null;
    this.expiredRequests = null;
    this.eventLog = null;

    this.spawnInterval = 180;
    this.frameCounter = 0;

    this.driverCounter = 1;
    this.customerCounter = 1;
  }

  update() {
    this.frameCounter++;

    if (this.frameCounter % this.spawnInterval === 0) {
      this.spawnRandomDriver();
      this.spawnRandomCustomer();
    }

    this.updateDrivers();

    this.processMatching();      // STUDENTS IMPLEMENT
    this.handleExpirations();    // STUDENTS IMPLEMENT
  }

  display() {
    this.map.drawGrid();
    this.renderDrivers();
    this.renderCustomers();
    this.renderHUD();
  }

  spawnRandomDriver() {
    let loc = this.map.getRandomLocation();
    let driver = new Driver("D" + this.driverCounter++, loc);

    // TODO: Insert into availableDrivers linked list
  }

  spawnRandomCustomer() {
    let loc = this.map.getRandomLocation();
    let customer = new Customer("C" + this.customerCounter++, loc);

    // TODO: Insert into pendingRequests linked list
  }

  updateDrivers() {
    // TODO:
    // Traverse driver list and call driver.update()
  }

  processMatching() {
    /*
      STUDENTS IMPLEMENT:

      1. Traverse pendingRequests
      2. For each request:
         - Traverse availableDrivers
         - Compute composite score
         - Select best driver
      3. Move nodes between lists
      4. Add event to eventLog
    */
  }

  handleExpirations() {
    /*
      STUDENTS IMPLEMENT:

      - If request older than time window
      - Remove from pendingRequests
      - Add to expiredRequests
      - Log event
    */
  }

  renderDrivers() {
    // Traverse availableDrivers list and call render()
  }

  renderCustomers() {
    // Traverse pendingRequests list and call render()
  }

  renderHUD() {
    fill(0);
    textSize(14);
    textAlign(LEFT);
    text("Ride-Share Simulation", 20, 25);
  }
}


























//--------TOWNMAP----------------------------------------------------------------------------------------------------------------------------------------------------------------------------





class TownMap {
  constructor(width, height, gridSize = 40) {
    this.width = width;
    this.height = height;
    this.gridSize = gridSize;
  }

  getRandomLocation() {
    return {
      x: floor(random(this.width / this.gridSize)) * this.gridSize + this.gridSize / 2,
      y: floor(random(this.height / this.gridSize)) * this.gridSize + this.gridSize / 2
    };
  }

  getDistance(loc1, loc2) {
    return dist(loc1.x, loc1.y, loc2.x, loc2.y);
  }

  drawGrid() {
    stroke(220);
    for (let x = 0; x < this.width; x += this.gridSize) {
      line(x, 0, x, this.height);
    }
    for (let y = 0; y < this.height; y += this.gridSize) {
      line(0, y, this.width, y);
    }
  }
}
