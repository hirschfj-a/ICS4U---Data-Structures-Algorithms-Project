//--------CUSTOMER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------


class Customer 
{
  constructor(id, location, x, y, fx, fy, passengers = 1, amenitiesRequired = []) 
  {
    
   // this.location = location;
    this.location = createVector(x,y) //this is the raw x and y coordinates
    this.finallocation = createVector(fx,fy) //this is the raw x and y coordinates for the customer final location (where they are being delivered)
    
    this.number = createVector(x,y) //---> is used for knowing where the customer is! (this is the processed x and y coordinates, and transfers it to the graph numbers)
    this.finalnumber = createVector(fx,fy) //(this is the processed final x and y coordinates, and it is transferred to the graph numbers)
    
    
    this.currentdelivery = null //current delivery, used as a curr when the driver follows the node linked list!
    this.currentdeliverydisplay = 0 //current delivery for display on the square!
    
    this.firsttestcustomer = true;
    this.beingserved = false;
    
    this.lastcustomerserved = false; //OR LASTCUSTOMERSERVING
    this.doneservingallcustomers = false;
    
    this.refreshing = false;
    
    this.onlyonce = true; //will help set home location
    
    
    this.id = id;
    this.next = null
    
    this.passengers = passengers;
    this.amenitiesRequired = amenitiesRequired;

    this.requestTime = millis();
  }

  display() 
  {
    if(this.currentdelivery !== null && this.doneservingallcustomers == false && this.lastcustomerserved == false && this.currentdelivery != listn.final.id && this.currentdelivery != listn.head.id && this.firsttestcustomer != true) // other customers are being served!
      {
   //     print("22222") (print("qwoibnfgbgoiu"))
         this.currentdeliverydisplay = this.currentdelivery.id - 1
      }

    if(this.doneservingallcustomers == false && this.lastcustomerserved == true) //last customer is being served!
      {
        this.currentdeliverydisplay = listn.final.id
      }
    if(this.firsttestcustomer == true) //the test customer is being served!
      {
        this.currentdeliverydisplay = 0
      }
   if(this.currentdelivery == listn.head.id && this.doneservingallcustomers == false) //the head of the list is being served!
     {
       this.currentdeliverydisplay = 1
     }
    
    
    if(this.currentdeliverydisplay == 0 && this.firsttestcustomer != true) //check to make sure the head of the list is being served
      {
        this.currentdeliverydisplay = 1
      }
    
    if(this.beingserved == true && this.doneservingallcustomers != true && this.refreshing == false)
      { 
        
    if(this.firsttestcustomer == true)
    fill(100,100,100) //gray
        
    if(this.currentdeliverydisplay == listn.head.id && this.firsttestcustomer == false)
    fill(100,100,185) //dark blue
        
        
    if(this.firsttestcustomer == false && this.currentdeliverydisplay != listn.head.id)
    fill(100,100,255); //blue
        
        
    rectMode(CENTER);
    rect(this.location.x, this.location.y, 18, 18);

    fill(255);
    textSize(10);
    textAlign(CENTER);
   // text(this.id, this.location.x, this.location.y - 14);
    text(this.currentdeliverydisplay, this.location.x, this.location.y + 3);
    
    
      }
  }
  
  displayfinallocation()
  {
    if(this.beingserved == true && this.doneservingallcustomers == false && this.refreshing == false)
      {
    fill(0,0,200) 
    rectMode(CENTER);
    rect(this.finallocation.fx, this.finallocation.fy, 10,10)
    
   //// print(this.finallocation.fx)
    
    this.location.x = listd.currentdriver.location.x
    this.location.y = listd.currentdriver.location.y
      }
    
  }
  
  setcustomerstart()
  {
    if(listc.printedtestcustomerinformation == false)
      {
     print("----------------------------- ")
     print("Current customer information:")
     print("(This is the first test customer!)")
     print("10")
     print("8")
        listc.printedtestcustomerinformation = true;
      }
    
    // if(listc.servingtestcustomer == true)
    // {
    //   //listc.currentcustomer = null;
    //   listc.servingtestcustomer = false;
    // }
    
    if(this.id == 1)
      {
    this.location.x = 40*10
    this.location.y = 40*8
    
    this.finallocation.fx = 40*5
    this.finallocation.fy = 40*4
      }
    else
      {
    this.location.x = 40*3
    this.location.y = 40*6
        
    this.finallocation.fx = 40*4
    this.finallocation.fy = 40*5
        
      }
    
    print("----------------------------- ")
  }
  
 // calllist()
 // {
 //   listn.customermovethroughlist()
 // }
  
  managelist()
  {
    if(this.doneservingallcustomers == true && this.lastcustomerserved == true)
      {
        
        listn.size = 2
        
        for(i = 2; i<=8; i++)
          {
       listn.remove(i)
          }
        
        for(i = 2; i<=8; i++)
         {
          listn.insertcustomer()
        }
        
        
        print("refreshed all customers! (kept the head of the list!)")
        listd.displaylist()
        listn.displaylist()
        
        
        
        this.currentdelivery = listn.head //restart back at the head and refresh!
        this.currentnode = listn.head
        
      //  listn.head.nodetaken = false
        
        this.doneservingallcustomers = false
        this.lastcustomerserved = false
        
        this.refreshing = true;
      }
    
    
    if(this.refreshing == true)
      {
        
        rect(420,350,900,800) //width and height to cover the screen while it refreshes
        fill(0);
    textSize(14);
    textAlign(LEFT)
        text("Ride-Share Simulation", 20, 25);
        text("(refreshing...)",20+200, 25)
        
        //refreshing will be disabled by the driver!
      }
    
  
}
  
  processcoordinates()
  {
   // print(listc.currentcustomer.id)
    
        //THIS WILL MOVE INTO ITS OWN METHOD LATER (below)
//-----------------------------------------
      //  print(customer.number.x)
      //  print(listc.currentcustomer.number.x)
      //   print(this.currentdelivery)
        
        this.number.x = this.currentdelivery.pos.x  //the customer copies the processed position information from linked list (node)
        this.number.y = this.currentdelivery.pos.y
        
        this.finalnumber.fx = this.currentdelivery.finalpos.x
        this.finalnumber.fy = this.currentdelivery.finalpos.y
        
  
        print("Current customer information:")
        if(this.currentcustomer == this.head)
        print("(This is the head of the list!)")
        
        print(this.currentcustomer)
        
        print(this.number.x)
        print(this.number.y)
        
        
      
    //when the customer has the processed coordinates, it turns the processed coordinates into location x and y coordinates so it can be displayed.
        
    for(let i = 0; i<=13; i++)
    {
    if(this.number.x == i)
    this.location.x = 40*i
      
    if(this.number.y == i)
    this.location.y = 40*i
      
      
    if(this.finalnumber.fx == i)
    this.finallocation.fx = 40*i
      
    if(this.finalnumber.fy == i)
    this.finallocation.fy = 40*i
      
    }
        
        
    
    if(this.lastcustomerserved == true) //FINAL CUSTOMER FULLY SERVED (when the final customer is being served, this will check if the last customer has been served once the customer is brought to its final location)
      {
        this.doneservingallcustomers = true; //this variable marks when the batch of customers have all been served
        
        print("----------------------------- ")
        print("i delivered the final customer to its final location!!!")
        print("my driver id:")
        print(listd.currentdriver.id)
        print("----------------------------- ")
      }
        

   if(this.currentcustomer !== this.final)
   {
  this.currentcustomer = this.currentcustomer.next;
    }
  else
   {
     if(this.lastcustomerserved == true)
      this.currentcustomer = null
     
     
     if(this.lastcustomerserved == false)
       {
       this.currentcustomer = this.currentcustomer //do nothing
       this.lastcustomerserved = true
       }
   }
        
//----------------------------------------------
    //THIS WILL MOVE INTO ITS OWN METHOD LATER (above)
    
    
    
  }
  
  
  
}
