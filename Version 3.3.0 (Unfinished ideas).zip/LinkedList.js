//--------LINKEDLISTS----------------------------------------------------------------------------------------------------------------------------------------------------------------------------


class LinkedList
  {
    
    constructor() 
  {
    //General:
    this.head = null;
    this.size = 1;
    
    this.final = null;
    
    
    //Nodes:
  //  this.currentnode = null; //the current node being looked at
    
    
    //Customers:
   // this.currentcustomercycle = null; //cycles through the current customer in the linked list (let this be "curr" for the customer's list)
    this.currentcustomeridcycle = 1; //cycles through the id of the current customer and checks if the full customer information can be stored (prepares this.currentcustomer for cycling through customers)
    this.currentcustomer = null; //stores the current customer and is unable to become null again
  //  this.prevcustomer = null;
  //  this.nextcustomer = null;
  
    this.servingtestcustomer = true;
    this.printedtestcustomerinformation = false;
    
    
    //Drivers:
    this.currentdriver = null; //let this be "curr" for the driver's list
    
    this.doneassigningfirstcapacity = false;
    this.doneassigningallcapacities = false;
    
    
  }
    
    
  insertnode(data) 
  { //ADD LINKS
    print("hi!")
    node = new Node(this.size++); //this.size++? (The node (or information of the customer) creates a copy in the list!)
      if(this.head === null)
        {
          this.head = node;
       //   this.currentnode = this.head //will slowly scroll with everything else as request information is picked and this will decide whether or not if a node is taken by a driver
      //    print("done!")
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          
        //  print(this.head)
       //   print(listc.currentcustomer.currentdelivery)
          listc.currentcustomer.currentdelivery = this.head; //START LIST BY SHOWING FIRST DELIVERY NEEDED (in the node linked list)!
        //  this.head.nodetaken = true;
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = node;
          
        }
  }
    
  insertdriver(data) 
  { //ADD LINKS
  //  print("hi!")
     driver = new Driver(this.size++); //this.size++? (Creates a copy of driver!)
      if(this.head === null)
        {
          this.head = driver;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = driver;
          
        }
  }
    
  insertcustomer(data) 
  { //ADD LINKS
  //  print("hi!")
     customer = new Customer(this.size++); //this.size++? (Creates a copy of customer!)
      if(this.head === null)
        {
          this.head = customer;
        //  print("done here!")
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          this.currentcustomer = this.head;
        //  print("currentcustomer")
        //  print(this.currentcustomer)
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = customer;
          
        }
  }
    
  search(predicate) // STUDENTS IMPLEMENT
   {
  let curr = this.head;
  while (curr !== null) 
  {
  //  print(curr)
    if (predicate === curr.id) 
    {
      print(curr)
      return curr;
    }
    curr = curr.next;
  }
  print("Could not find that node!")
     
  return null;
}
    
    
  remove(n) //remove(n) OR delete(data)
   {
      print("-----------------")
       print("REMOVING Link #:")
       print(n) //data or 'n'
       print("-----------------")
      
       let prev = null;
       let curr = this.head;
       while(curr.id !== n)//keep moving if not target link
         {
           prev = curr;
           curr = curr.next;
           if(curr === null) //reached end of list?
             {
               return; //end
             }
         }
       prev.next = curr.next //(removes link)
   }
    
    
displaylist()
  {
    print("-----------------------------")
      print("NOW DISPLAYING!:")
      print("head:")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null && curr.next !== null)
        {
          print(curr)
          curr = curr.next;
          
        }
    
    //runs when the while loop is false (last one):
       print(curr)
       this.final = curr
       curr = curr.next;
       
    print("final:")
     print(this.final)
      
    
  //  print("currentcustomer:")
  //  print(listc.currentcustomer)
      
      print("-----------------------------")
    
  }
    
    
 //  traverse(callback) 
 // {
 //     // STUDENTS IMPLEMENT
 // }
    
    
    
drivercommands() //traverses through the list (for drivers)
  {
   this.currentdriver = this.head; //act as curr
    
    while(this.currentdriver !== null)
        {
          this.driveronlyonce()
          
       //   FIX! (FIXED!)
          
          if(this.doneassigningfirstcapacity == false)
            {
              this.currentdriver.capacity = 3;
        
              this.doneassigningfirstcapacity = true
            }
          if(this.currentdriver.capacity != 3 && this.doneassigningfirstcapacity == true)
            {
              this.currentdriver.capacity = 5;
              
              this.doneassigningallcapacities = true //all customers will now have a driver that exists for them (a driver can now hold any capacity)
            }
          
         // if(this.doneassigningallcapacities == true)
          //any driver that exists can have any capacity now
          
          
          this.currentdriver.drawhome()
          this.currentdriver.display()
          this.currentdriver.update()
          
          this.currentdriver.alternatemovedriver()
          
          if(listc.currentcustomer.beingserved == true && this.currentdriver.servingcustomer == true)
            {
          this.currentdriver.movedriver()
         //    print(this.currentdriver.id)
          //   print("i am running")
            }
          
          if(listc.currentcustomer.beingserved == false && this.currentdriver.servingcustomer == false && this.currentdriver.status === "AVAILABLE") //only allows one driver at a time 
            {
          listc.currentcustomer.beingserved = true
          this.currentdriver.servingcustomer = true
         //     print("i ran")
            }
          
          this.currentdriver = this.currentdriver.next; //cycles through each driver
        }
          
    
  }
    
    
customercommands() //traverses through the list (for customers)
  {
    
   if(this.currentcustomeridcycle <= this.size-1) //cycles through ids
      {
       this.currentcustomer = this.head
        let curr = this.head
     //   let prev = this.final;   //prev will become this.final to allow a circle loop
    //    let next = this.head.next
        
        while(this.currentcustomer !== null && curr !== null)
          {
            if(this.currentcustomeridcycle === curr.id)
              {
                this.currentcustomer = curr
             //   this.prevcustomer = prev
             //   this.nextcustomer = curr.next
                this.customeronlyonce()
              }
            
            curr = curr.next; //curr moves ahead
            
            if(curr === this.head) //if curr.next !== null
              {
                
//             if(curr.next !== null)
//             this.nextcustomer = curr.next; //nextcustomer moves ahead after curr
            
//             if(curr.next === null)
//             this.nextcustomer = null;
                
              }
            
//              if(curr === this.head)  //this creates a circle loop where the previous customer is the final one if the current customer is at the head
//                {
//                 prev = this.final
//                }
            
//              if(prev === null && curr !== this.head)
//               prev = this.head
            
//              // if(prev === null && curr === this.head)
//              //  prev = this.final
            
//              if(prev !== null)
//              prev = prev.next;
          }
        
      this.currentcustomeridcycle = this.currentcustomeridcycle + 1
      }
    
    
    //is the currentcustomer equal to the size of the list? (is currentcustomer on the final node?)
    if(this.currentcustomeridcycle == this.size)  
      {
        let finalprev = this.head
        
        if(this.size-1 !== 2) //if the size of the list is not 2, then scroll through the list
          {
           while(finalprev.next !== this.final)
            {
            finalprev = finalprev.next
            }
          }
      this.currentcustomer = this.final
     // this.prevcustomer = finalprev
     // this.nextcustomer = this.head
        
      this.currentcustomeridcycle = 1;
      }
    
    
    
  //  if(this)
    
    
  //   print(this.currentcustomer.currentdelivery)
  //   print(this.prevcustomer.currentdelivery)
    
    
    
 //   print(this.prevcustomer)
 //   print(this.nextcustomer)
    
    //check to see if the same customer is being served: (listc)
    
//     if(this.prevcustomer.currentdelivery !== null)
//       {
        
//       }
    
    
    
    
//    //    if(this.currentcustomer !== this.head) //if prevcustomer is not null (but next could be null)
//    //      {
//         //   print("prevcustomer is not null")
//         //   print(this.currentcustomer.currentdelivery)
//         //   print(this.prevcustomer.currentdelivery)
           
//            if(this.currentcustomer.currentdelivery == this.prevcustomer.currentdelivery) //same node being looked at?
//              {
//            print("moving on from this node!")
//             this.currentcustomer.currentdelivery = this.currentcustomer.currentdelivery.next
//              }
//     //     }
    
//    ////    if(this.currentcustomer === this.head) //if next is not null (but prev is null)
//     //     {
//            if(this.currentcustomer.currentdelivery == this.nextcustomer.currentdelivery)
//              {
//                print("moving on from this node 2!")
//                this.currentcustomer.currentdelivery = this.currentcustomer.currentdelivery.next
//              }
//      //    }
  
    
    
    
    
    
    
    
    // this.currentcustomer.display()
    // this.currentcustomer.displayfinallocation()
    // this.currentcustomer.managelist()
    
  //  print(this.currentcustomer.id)
    
    
    
    
    
//    this.currentcustomercycle = this.head; //act as curr
//  //   print(this.head)
//   //  print(this.currentcustomer)
    
//     while(this.currentcustomercycle !== null)
//         {
//           if(this.currentcustomercycle.onlyonce == true)
//             {
//               this.currentcustomercycle.setcustomerstart()
//               this.currentcustomercycle.onlyonce = false
              
//           //    print("sfnq0fqoipqwf")
//             }
          
          
//        //  print(listc.currentcustomer.id)
//        //   print(this.currentcustomer.id)
          
          
//           this.currentcustomercycle.display()
//           this.currentcustomercycle.displayfinallocation()
//           this.currentcustomercycle.managelist()
//        //   
          
//        //   this.currentdriver.update()
          
//       //    this.currentdriver.alternatemovedriver()
          
//          //  if(customer.beingserved == true && this.currentdriver.servingcustomer == true)
//          //    {
//          //  this.currentdriver.movedriver()
//          // //    print(this.currentdriver.id)
//          //  //   print("i am running")
//          //    }
          
//          //  if(customer.beingserved == false && this.currentdriver.servingcustomer == false && this.currentdriver.status === "AVAILABLE") //only allows one driver at a time 
//          //    {
//          //  customer.beingserved = true
//          //  this.currentdriver.servingcustomer = true
//          // //     print("i ran")
//          //    }
          
//        //   if(this.currentcustomer.next !== null)
          
//        //   this.currentcustomer = this.currentcustomercycle
//           this.currentcustomercycle = this.currentcustomercycle.next; //cycles through each customer
//         }
    
   // print(this.size - 1)
    //this.size - 1 is the amount of customers we have and need!
    
    
    
 //   if(this.currentcustomer)
    
    // if(this.currentcustomer === null)
    //   {
    //   //  print(this.currentcustomer)
    // //    this.currentcustomer = this.head
    //   }
    // if(this.currentcustomer !== null)
    //   {
    //  //   print(this.currentcustomer)
    //   }
          
    
  }
    
  customeronlyonce() //run these only once for the customers
  {
    if(this.currentcustomer.onlyonce == true)
             {
              this.currentcustomer.setcustomerstart()
               listc.currentcustomer.currentdelivery = listn.head; //make all deliveries start at the head
               
               
               this.currentcustomer.onlyonce = false
              
           //    print("sfnq0fqoipqwf")
           //    print(this.currentcustomer.id)
             }
  }
    
  
 driveronlyonce() //run these only once for the drivers
    {
      if(this.currentdriver.onlyonce == true) 
            {
              this.currentdriver.starthome()
              this.currentdriver.onlyonce = false
              
            //  print("fqwoifoufbw")
            }
    }
    
    
    
    
nodemovethroughlist() //traverse through the list for requests (only runs if nodetaken == false)
  {
  //  if(listc.currentcustomer.currentdeliverydisplay !== 0) //currentdelivery !== null
  //  listc.currentcustomer.currentdelivery.nodetaken = true;
      
//     print("current node:")
//     print(listn.currentnode)
//     print(listn.currentnode.nodetaken)
    
//     print("current delivery:")
//     print(listc.currentcustomer.currentdelivery)
    
     if(listc.currentcustomer.currentdelivery.nodetaken == true)
       {
         
         
         
         
       }
    
    
    
  if(listc.currentcustomer.currentdelivery.nodetaken == false)
    {
      
      listc.currentcustomer.currentdelivery.nodetaken = true;
      
      
    
    while(listd.currentdriver.currentRide !== null && listd.currentdriver.status == "AVAILABLE" && listc.currentcustomer.currentdelivery.nodetaken == true) //at this part, the driver sees the customer and notices the customer as its current customer that it wants to serve
      {
    //    print(listd.currentdriver.currentRide)
     //   print(listd.currentdriver.status)
        
        listc.currentcustomer.processcoordinates()
        
//     //THIS WILL MOVE INTO ITS OWN METHOD LATER (below)
// //-----------------------------------------
//       //  print(customer.number.x)
//       //  print(listc.currentcustomer.number.x)
        
//         customer.number.x = customer.currentcustomer.pos.x  //the customer copies the processed position information from linked list (node)
//         customer.number.y = customer.currentcustomer.pos.y
        
//         customer.finalnumber.fx = customer.currentcustomer.finalpos.x
//         customer.finalnumber.fy = customer.currentcustomer.finalpos.y
        
  
//         print("Current customer information:")
//         if(customer.currentcustomer == this.head)
//         print("(This is the head of the list!)")
        
//         print(customer.currentcustomer)
        
//         print(customer.number.x)
//         print(customer.number.y)
        
        
      
//     //when the customer has the processed coordinates, it turns the processed coordinates into location x and y coordinates so it can be displayed.
        
//     for(let i = 0; i<=13; i++)
//     {
//     if(customer.number.x == i)
//     customer.location.x = 40*i
      
//     if(customer.number.y == i)
//     customer.location.y = 40*i
      
      
//     if(customer.finalnumber.fx == i)
//     customer.finallocation.fx = 40*i
      
//     if(customer.finalnumber.fy == i)
//     customer.finallocation.fy = 40*i
      
//     }
        
        
    
//     if(customer.lastcustomerserved == true) //FINAL CUSTOMER FULLY SERVED (when the final customer is being served, this will check if the last customer has been served once the customer is brought to its final location)
//       {
//         customer.doneservingallcustomers = true; //this variable marks when the batch of customers have all been served
        
//         print("----------------------------- ")
//         print("i delivered the final customer to its final location!!!")
//         print("my driver id:")
//         print(listd.currentdriver.id)
//         print("----------------------------- ")
//       }
        

//    if(customer.currentcustomer !== this.final)
//    {
//   customer.currentcustomer = customer.currentcustomer.next;
//     }
//   else
//    {
//      if(customer.lastcustomerserved == true)
//       customer.currentcustomer = null
     
     
//      if(customer.lastcustomerserved == false)
//        {
//        customer.currentcustomer = customer.currentcustomer //do nothing
//        customer.lastcustomerserved = true
//        }
//    }
        
// //----------------------------------------------
//     //THIS WILL MOVE INTO ITS OWN METHOD LATER (above)
        
   listd.currentdriver.assignRide(customer,500) //will go to the customer! (500 or 90 for testing)
 
      }
    
   print("-----------------------------")
    
    
     }
    
  }
    
    
    
    
    
    
    
  }





















