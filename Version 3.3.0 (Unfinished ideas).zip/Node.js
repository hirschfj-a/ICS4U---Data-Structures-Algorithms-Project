//--------NODE----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class Node 
{ //links or Nodes
  constructor(id) 
  { //request id
    this.id = id; //id
    this.next = null;
   // this.purpose = round(random(0,1)); //0 makes the node represent a customer while 1 makes the node represent a driver [UNUSED]
    this.pos = createVector(round(random(0,13)),round(random(0,10))) //the position information from the node is already processed and does not have raw coordinates. The customer will process its raw coordinates to match the processed node coordinates.
    
    this.finalpos = createVector(round(random(0,13)),round(random(0,10)))
    
    this.nodetaken = false;
    
    
 //   this.capacityneeded = round(random(1,5))
    //the capacity needed shows how many passengers will enter the cars! the capacity of the car will need to be above or equal to this number to accept the request
    
  }
  
  
}