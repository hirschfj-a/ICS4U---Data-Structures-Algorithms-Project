//--------SKETCH----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

let simulation;
let driver
let customer
let node
//let request

function setup() 
{
 // print("Hello World!")
  createCanvas(520, 400); //13 squares X, 10 squares Y
  simulation = new SimulationController(width, height);
  
  frameRate(60)
//  print(frameCount)
  
 /// customer = new Customer()
  
 // driver = new Driver()
   //driver.starthome()
  
  
  listc = new LinkedList() //linked list instance for customers (customers mark the relevant nodes for the drivers to see, while the nodes hold the core information for the request)
  
  listn = new LinkedList() //linked list instance for nodes (hold request for customers)
  listd = new LinkedList() //linked list instance for drivers
  
  //--------------------------
  //THE SYSTEM FOR THE CUSTOMERS CAN ONLY HANDLE 2 FOR NOW
  for(i = 1; i<=2; i++) //2 default ()
   {
     listc.insertcustomer()
   }
  //---------------------------
  
  
  
  for(i = 1; i<=4; i++) //4 default (turns to 8 after the first refresh)
    {
  listn.insertnode()
   }
  
  for(i = 1; i<=2; i++) //2 default
   {
     listd.insertdriver()
   }
  
  
  listd.displaylist()  //prints out the linked lists and shows the data inside
  listc.displaylist()
  listn.displaylist()
//  customer.setcustomerstart() //prints out the information for the customer and starts the customer at the first point

  
}

function draw() 
{
  background(245);
  simulation.update();
  simulation.display();
  
  simulation.control();
  // print(listd.head)
  // print(listc.head)
  // print(listn.head)
 // print(listc.currentcustomeridcycle)
 // print(listc.currentcustomer)
  
  // print("--------")
  // print(listc.prevcustomer)
  // print(listc.currentcustomer)
  // print(listc.nextcustomer)
  // print("-------")
  
  //  print("current delivery:")
  // //  print(listc.currentdelivery)
  //   print(listc.currentcustomer.currentdelivery)
  
  //if(listc.currentcustomer.currentdelivery !== null)
//  print(listc.currentcustomer.currentdelivery.nodetaken)
  
 // if(listc.currentcustomer.currentdeliverydisplay !== 0) //currentdelivery !== null
  //print(listc.currentcustomer.currentdelivery.nodetaken)
//  print(listc.currentcustomer.currentdelivery)
  
  listc.customercommands()
  
  listd.drivercommands() //keeps drivers updated by scrolling through the drivers and allowing them to update

  
 // customer.display()
 // customer.managelist()
  
  
  for(let i = 0; i<=13; i++)
    {
      fill('pink')
      text(i,i*39+5,10)
    }
  
  for(let i = 1; i<=10; i++)
    {
      fill('pink')
      text(i,5,i*40)
    }
  
 // print(customer.beingserved)
 //  print(customer.currentcustomer)
 // print(customer.firsttestcustomer)
  
  //print(customer.lastcustomerserved)
//  print(customer.doneservingallcustomers)
  
 // print(listc.currentcustomer.currentdelivery)
  
}

function mouseReleased() //for testing!
{
  print("-----")
  print("Hello!")
  
  print("currentcustomerid:")
  print(listc.currentcustomer.id)
  print(listc.currentcustomer.currentdelivery)
  
  
 // print(listc.prevcustomer)
//  print(listc.currentcustomer)
  
 // print(customer.currentcustomer.id)
  //print(listc.currentcustomer.id)
  
  //print(listc.currentcustomeridcycle)
  
 // print(listd.currentdriver)
//  print(listc.currentcustomer.id)
 // print(customer.location.x)
//  print(customer.number.x)
  
  
  
 // listn.search(4)
 // listc.search(4)
  
 // listd.search(2)
  
  
  
 // customer.refreshing = true
  
//  listc.displaylist()
 // listd.displaylist()
  
  print("-----")
}






































































