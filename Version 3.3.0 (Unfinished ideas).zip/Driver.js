//--------DRIVER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------




class Driver 
{
  constructor(id, location, x, y, speed, capacity, amenities = []) 
  {
  //  this.location = location;
    this.location = { x: x, y: y };
    this.horizontal = true;
    this.speed = 2; //1 or 2 is default
    
    
    this.homelocation = createVector(x,y)
    this.onlyonce = true //runs commands only once in the beginning
    
    this.servingcustomer = false;
    
    
    
    this.id = id;
    this.next = null;
    
    
    this.capacity = capacity
    
    
    this.amenities = amenities;

    this.status = "AVAILABLE"; //AVAILABLE,BUSY,CARRYING,RESTING
    this.currentRide = null;
    this.busyTimer = 0;
    this.restingTimer = 500; //500 or 90
  }

  assignRide(request, duration) 
  { //assignRide(request,duration) optional
    this.status = "BUSY";
    this.currentRide = request;
    this.busyTimer = duration;
    
    if(this.location.x == 40*1 && this.location.y == 40*2) //if at home?
      {
    this.horizontal = true
  //  print("i see the customer")
      }
  }
  
  movedriver()
  {
  //  print(this.capacity)
    
    if(this.status === "BUSY")
      {
        listc.currentcustomer.display()
        
        stroke('magenta')
        
        customer.beingserved = true;
        this.servingcustomer = true;
        
   line(this.location.x,this.location.y,listc.currentcustomer.location.x,this.location.y)
   line(listc.currentcustomer.location.x,listc.currentcustomer.location.y,listc.currentcustomer.location.x,this.location.y)
        
        if(this.horizontal == true)
          {
        if(this.location.x < listc.currentcustomer.location.x)
      this.location.x = this.location.x + this.speed
        if(this.location.x > listc.currentcustomer.location.x)
      this.location.x = this.location.x - this.speed
            
      if(this.location.x == listc.currentcustomer.location.x)
         this.horizontal = false
       
          }
        
        else if (this.horizontal == false)
          {
            
        if(this.location.y < listc.currentcustomer.location.y)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > listc.currentcustomer.location.y)
      this.location.y = this.location.y - this.speed
      
            
            
          if(this.location.y == listc.currentcustomer.location.y && simulation.checkedonce == false)
            {
      //        print("i made it to the customer!")
              
              print(listc.currentcustomer.id)
              print(this.id)
              
              this.horizontal = true
              this.status = "CARRYING"
              
              listc.currentcustomer.displayfinallocation()
              
          //    this.status = "AVAILABLE";
          //    this.currentRide = null; 
              
              simulation.checkedonce = true;
            }
            
          }
        
      }
    
    if(this.status === "CARRYING") //has customer
      {
        
        listc.currentcustomer.displayfinallocation()
        listc.currentcustomer.beingserved = true;
        this.servingcustomer = true;
        
       stroke('orange')
        

    line(this.location.x,this.location.y,listc.currentcustomer.finallocation.fx,this.location.y)
    line(listc.currentcustomer.finallocation.fx,listc.currentcustomer.finallocation.fy,listc.currentcustomer.finallocation.fx,this.location.y)
        
        
        if(this.horizontal == true)
          {
        if(this.location.x < listc.currentcustomer.finallocation.fx)
      this.location.x = this.location.x + this.speed
        if(this.location.x > listc.currentcustomer.finallocation.fx)
      this.location.x = this.location.x - this.speed
            
      if(this.location.x == listc.currentcustomer.finallocation.fx)
         this.horizontal = false
          }
        
        else if (this.horizontal == false)
          {
            
        if(this.location.y < listc.currentcustomer.finallocation.fy)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > listc.currentcustomer.finallocation.fy)
      this.location.y = this.location.y - this.speed
      
            
            
          if(this.location.y == listc.currentcustomer.finallocation.fy)
            {
              if(listc.currentcustomer.refreshing == false)
                {
            print("i delivered the customer to its final location!")
              print("my driver id:")
              print(this.id)
        //      print(customer.currentcustomer)
            print("-----")
                }
              
              listc.currentcustomer.beingserved = false;
              this.servingcustomer = false;
              
              this.horizontal = true
              this.status = "AVAILABLE"; //resting or available
          
    //      if(listc.currentcustomer.currentdelivery.nodetaken == false)
    //        {
          listn.nodemovethroughlist() //calllist()
     //       }
              
          this.currentRide = null;
      
              
            if(listc.currentcustomer.firsttestcustomer == true)
              listc.currentcustomer.firsttestcustomer = false //''
              
            if(listc.currentcustomer.refreshing == true)
              {
                listc.currentcustomer.refreshing = false
                print("refreshing done!")
              }
              
            if(simulation.checkedonce == true)
              simulation.checkedonce = false
            
              
              this.status = "RESTING"
              
            }
            
          }
        
      }
    
    
    if(this.status === "AVAILABLE") //slowly return home, look for future customers
      {
        
     if(this.horizontal == true)
       {
         if(this.location.x < this.homelocation.x)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > this.homelocation.x)
        this.location.x = this.location.x - this.speed/2
         
         if(this.location.x == this.homelocation.x)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < this.homelocation.y)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > this.homelocation.y)
       this.location.y = this.location.y - this.speed/2
          
          if(this.location.y == this.homelocation.y)
          this.horizontal = true
        }
        
   //   print(customer.currentcustomer)
        
        if(listd.currentdriver.currentRide !== listn.final && listc.currentcustomer !== null) //reassigns a customer and assigns a customer
          {
       listd.currentdriver.assignRide(listc.currentcustomer,500)
          }
        
        
        
      }
  
    
  }
  
  alternatemovedriver()
  {
      if(this.status === "RESTING") //slowly return home and wait
      {
        this.currentRide = null
        this.servingcustomer = false;
        
     if(this.horizontal == true)
       {
         if(this.location.x < this.homelocation.x)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > this.homelocation.x)
        this.location.x = this.location.x - this.speed/2
         
         if(this.location.x == this.homelocation.x)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < this.homelocation.y)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > this.homelocation.y)
       this.location.y = this.location.y - this.speed/2
          
          if(this.location.y == this.homelocation.y)
          this.horizontal = true
        }
        
        
      }
    
    
  }

  update() {
    if (this.status === "BUSY") 
    {
      this.busyTimer--; //this.busyTimer = this.busyTimer - 1
      if (this.busyTimer <= 0) 
      {
        this.status = "RESTING";
        this.currentRide = null;    
      }
    }
    
    if(this.status === "RESTING")
      {
        if(this.location.x == this.homelocation.x && this.location.y == this.homelocation.y)
          {
         this.restingTimer--; //this.restingTimer = this.restingTimer - 1;
            text(this.restingTimer,this.homelocation.x,this.homelocation.y + 20)
          }
        
        if(this.restingTimer <= 0)
          {
            this.status = "AVAILABLE"
            this.restingTimer = round(random(90,500));
            
          } 
        
      }
  }

  display() 
  {
    if(this.status === "AVAILABLE")
      fill("green")
    if(this.status === "BUSY")
      fill("red")
    if(this.status === "CARRYING")
      fill("orange")
    if(this.status === "RESTING")
      fill("black")
    
    ellipse(this.location.x, this.location.y, 22);
    fill(0);
    textSize(10);
    textAlign(CENTER);
    
    fill(100,100,100)
    text(this.id,this.location.x,this.location.y + 3)
  }
  
  drawhome() //draw a dot that represents home
  {
    if(this.id == 1)
      {
        this.homelocation.x = 40
        this.homelocation.y = 80
      }
    else if(this.id == 2)
      {
        this.homelocation.x = 40*12
        this.homelocation.y = 80
      }
    
    
    fill(255,0,0)
    circle(this.homelocation.x,this.homelocation.y,5) //40 each
    fill(0)
    textSize(10)
   // text("Home",28,65)
    
    if(this.id == 1)
    text("Home",this.homelocation.x-12,this.homelocation.y - 15)
    else
    text("Home",this.homelocation.x-3,this.homelocation.y - 15)
    
    text(this.id,this.homelocation.x-12+30,this.homelocation.y - 15)
  }
  
  starthome() //start the driver at home
  {
    
    if(this.id == 1)
      {
        this.location.x = 40 //40*1
        this.location.y = 80 //40*2
      }
    else if(this.id == 2)
      {
        this.location.x = 40*12
        this.location.y = 80
      }
    
    
    
  }
}
































