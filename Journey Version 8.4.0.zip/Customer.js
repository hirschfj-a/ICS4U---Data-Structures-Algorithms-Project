//--------CUSTOMER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------


class Customer 
{
  constructor(id, location, x, y, fx, fy, passengers = 1, amenitiesRequired = []) 
  {
    this.location = createVector(x,y)
    this.finallocation = createVector(fx,fy)
    
    this.number = createVector(x,y) //---> is used for knowing where the customer is! 
    this.finalnumber = createVector(fx,fy)
    this.currentcustomer = null //current delivery being focused, used as a curr when the driver follows the linked list! (the drivers use this to look ahead to see the next customer)
    this.currentcustomerdisplay = 0 //current delivery for display on the square! (shows the id of the node being displayed)
    this.currentcustomerdisplaynode = null; //current node being displayed (follows behind currentcustomer)
    
    this.firsttestcustomer = true;
    this.beingserved = false;
    
    this.beingcarried = false;
    
    this.lastcustomerserved = false; //represents if the last customer is being served
    this.doneservingallcustomers = false;
    
    this.refreshing = false;
    
    this.timeelapsed = 0; //the elapsed time will represent each second
    this.customerrating = -1; //addcustomerratingsystem
    
    this.sumoftimeelapsed = 0; //all time elapsed added for each!
    this.numberoftimeelapsedinputs = 0; //amount of inputs for time elapsed (counts +1 each time)
    this.averagetimeelapsed = 0; //the average for the time elapsed within each refresh (will be sumoftimeelapsed/numberoftimeelapsedinputs)
    
    
    this.unhappyreviewcount = 0;
    this.overallgoodrating = true; //If the overall good ratings are true, then it is more likely for the drivers to continue staying at their current station. If the overall good ratings are false, then it is more likely for the drivers to change their location to try a different position
    
    
    this.failedreachingcustomer = false;
    
    
    
    
    this.id = id;
    this.passengers = passengers;
    
    this.amenitiesRequired = amenitiesRequired;

    this.requestTime = millis();
  }

  display() 
  {
    if(this.currentcustomer !== null && this.doneservingallcustomers == false && this.lastcustomerserved == false && this.currentcustomer != listc.final.id && this.currentcustomer != listc.head.id && this.firsttestcustomer != true) // other customers are being served!
      {
         this.currentcustomerdisplay = this.currentcustomer.id - 1
      }

    if(this.doneservingallcustomers == false && this.lastcustomerserved == true) //last customer is being served!
      {
        this.currentcustomerdisplay = listc.final.id
      }
    if(this.firsttestcustomer == true) //the test customer is being served!
      {
        this.currentcustomerdisplay = 0
      }
   if(this.currentcustomer == listc.head.id && this.doneservingallcustomers == false) //the head of the list is being served!
     {
       this.currentcustomerdisplay = 1
     }
    
    
    if(this.currentcustomerdisplay == 0 && this.firsttestcustomer != true) //check to make sure the head of the list is being served
      {
        this.currentcustomerdisplay = 1
      }
    
    if(this.beingserved == true && this.doneservingallcustomers != true && this.refreshing == false)
      { 
        
    if(this.firsttestcustomer == true)
    fill(100,100,100) //gray
        
    if(this.currentcustomerdisplay == listc.head.id && this.firsttestcustomer == false)
    fill(100,100,185) //dark blue
        
        
    if(this.firsttestcustomer == false && this.currentcustomerdisplay != listc.head.id)
    fill(100,100,255); //blue
        
        
    rectMode(CENTER);
    rect(this.location.x, this.location.y, 18, 18);

    fill(255);
    textSize(10);
    textAlign(CENTER);
   // text(this.id, this.location.x, this.location.y - 14);
    text(this.currentcustomerdisplay, this.location.x, this.location.y + 3);
    
    
      }
  }
  
  update() //determines how long the customer has interacted with the driver (count faster as simulation speeds up)
  {
      // print(this.overallgoodrating)
      //  print(listd.amountofdrivers)
    // print(this.timeelapsed)
    
   //  print("total sum of time elapsed")
   //  print(customer.sumoftimeelapsed)
   //  print("# of inputs")
   //  print(customer.numberoftimeelapsedinputs)
   //  print("average time elapsed")
   // print(customer.averagetimeelapsed)
        
        if(simulation.simulationspeed != 1)
        this.timeelapsed = this.timeelapsed + 1*(simulation.simulationspeed-1)
    
        else if(simulation.simulationspeed == 1)
        this.timeelapsed = this.timeelapsed + 1
    
    ////for testing:
   //// this.timeelapsed = this.timeelapsed + 100
    
//     ////for testing 2:
 //    this.timeelapsed = this.timeelapsed + 10
    
    
//     if(this.timeelapsed > 2000 && this.firsttestcustomer == false) //did the drivers fail to reach the customer?
//       {
//         print("customer is failing to be served")
//         this.customerrating = 0;
//         this.unhappyreviewcount = this.unhappyreviewcount + 1;
        
//         if(this.unhappyreviewcount >= 1)
//         this.overallgoodrating = false;
        
//         this.failedreachingcustomer = true;
        
      
        
//         if(this.failedreachingcustomer == true)
//           {
            
            
//         this.beingserved = false;
//         this.timeelapsed = 0;
        
// //         listd.driverwithgoodmood = false;
// //         listd.driverwithmatchingmusic = false;
        
// //         listd.driverthatisbusy = false;
        
// //         listd.knownclosestdistance = 100000000;
    
    
// //         listd.prioritizedistance = true;
        
        
//         print(listd.currentdriver)
            
//      //   listd.currentdriver.status = "AVAILABLE"
            
//      //   listc.customermovethroughlist()
            
            
//          this.failedreachingcustomer = false
//           }
        
        
//         this.beingserved = false;
//         this.timeelapsed = 0;
        
//         listd.driverwithgoodmood = false;
//         listd.driverwithmatchingmusic = false;
        
//         listd.driverthatisbusy = false;
        
//         listd.knownclosestdistance = 100000000;
    
    
//         listd.prioritizedistance = true;
        
        
//         if(customer.firsttestcustomer == true)
//         customer.firsttestcustomer = false //''
        
        
        
//      //   listc.customermovethroughlist()
//        // listc.movethroughcustomerlist()
//       }
    
  }
  
  displayfinallocation()
  {
    if(this.beingserved == true && this.doneservingallcustomers == false && this.refreshing == false)
      {
    fill(0,0,200) 
    rectMode(CENTER);
    rect(this.finallocation.fx, this.finallocation.fy, 10,10)
    
   //// print(this.finallocation.fx)
    
    this.location.x = listd.currentdriver.location.x
    this.location.y = listd.currentdriver.location.y
      }
    
  }
  
  setcustomerstart()
  {
     print("----------------------------- ")
     print("Current customer information:")
     print("(This is the first test customer!)")
     print("10")
     print("8")
    
    this.location.x = 40*10
    this.location.y = 40*8
    
    this.finallocation.fx = 40*5
    this.finallocation.fy = 40*4
    
    print("----------------------------- ")
  }
  
  
  
  managelist()
  {
    if(this.doneservingallcustomers == true && this.lastcustomerserved == true)
      {
        
        listc.size = 2
        
        if(this.overallgoodrating == false)
        listd.size = 2
        
        
        for(i = 2; i<=8; i++) //refreshes customer requests
          {
       listc.remove(i)
          }
        
        for(i = 2; i<=8; i++)
         {
          listc.insertcustomer()
        }
        
        
    if(this.overallgoodrating == false)
      {
        
        for(i = 2; i<=8; i++) //refreshes drivers (their homes and mood will be random again) 
          {
       listd.remove(i)
          }
        
        listd.amountofdrivers = 1; 
        
        for(i = 3; i<=round(random(4,6)); i++) //3,5 or 4,6
         {
          listd.insertdriver()
          listd.amountofdrivers = listd.amountofdrivers + 1;
        }
        
        //If too many drivers are added, it risks the drivers miscommunicating with each other, and they might overtake each other's request too often since there can be a variety of different amenities each driver has. If not enough drivers are added, it could risk the drivers being too far away from the customer. Both of these could make it so that they will reach the driver very late by accident.
        
      }
        
        
        
        print("refreshed all customers! (kept the head of the list!)")
        listd.displaylist()
        listc.displaylist()
        
        listlog.displaylist()
        
        this.beingserved = false;
        
        
        
        this.currentcustomer = listc.head //restart back at the head and refresh!
        
        this.currentcustomerdisplaynode = null
        
        this.doneservingallcustomers = false
        this.lastcustomerserved = false
        
        listd.prioritizedistance = false;
        
        this.refreshing = true;
        
     simulation.simulationspeedstore = simulation.simulationspeed
        simulation.simulationspeed = 9;
        
        
      }
    
    
    if(this.refreshing == true)
      {
        
        rect(420,350,900,800) //width and height to cover the screen while it refreshes
        fill(0);
    textSize(14);
    textAlign(LEFT)
        text("Ride-Share Simulation", 20, 25);
        text("(refreshing...)",20+200, 25)
        
        //refreshing will be disabled by the driver!
        //simulation.simulationspeed will become simulation.simulationspeedstore
      }
    
  
}
  
  processcoordinates()
  {
    
    customer.number.x = customer.currentcustomer.pos.x  //position information from linked list
        customer.number.y = customer.currentcustomer.pos.y
        
        customer.finalnumber.fx = customer.currentcustomer.finalpos.x
        customer.finalnumber.fy = customer.currentcustomer.finalpos.y
        
  
//         print("Current customer information:")
//         if(customer.currentcustomer == listc.head)
//         print("(This is the head of the list!)")
        
//         print(customer.currentcustomer)
        
//         print(customer.number.x)
//         print(customer.number.y)
    
    
    
    for(let i = 0; i<=13; i++)
    {
    if(customer.number.x == i)
    customer.location.x = 40*i
      
    if(customer.number.y == i)
    customer.location.y = 40*i
      
      
    if(customer.finalnumber.fx == i)
    customer.finallocation.fx = 40*i
      
    if(customer.finalnumber.fy == i)
    customer.finallocation.fy = 40*i
      
    }
    
    
    
    
    
    
    
    
    
  }
  
  
  
  
  
  
  
  
  
}
