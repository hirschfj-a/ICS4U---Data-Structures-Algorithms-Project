//--------DRIVER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------




class Driver 
{
  constructor(id, location, x, y, speed, capacity, amenities = []) 
  {
  //  this.location = location;
    this.location = { x: x, y: y };
    this.horizontal = true;
    this.speed = 2; //1 or 2 is default
    
    this.homelocation = createVector(x,y)
    this.drawnhome = false;
    this.onlyonce = true //runs commands only once in the beginning
    
    this.servingcustomer = false;
    
    
    this.id = id;
    this.next = null;
    
    
    this.capacity = capacity
    this.capable = true;
    this.canholdanycustomer = false;
    
    
    this.amenities = amenities;

    this.status = "AVAILABLE"; //AVAILABLE,BUSY,CARRYING,RESTING
    this.currentRide = null;
    this.busyTimer = 0;
    this.restingTimer = 500; //500 or 90
  }

  assignRide(request, duration) 
  { //assignRide(request,duration) optional
    this.status = "BUSY";
    this.currentRide = request;
    this.busyTimer = duration;
    
    if(this.location.x == 40*1 && this.location.y == 40*2) //if at home?
      {
    this.horizontal = true
  //  print("i see the customer")
      }
  }
  
  movedriver()
  {
  //  print(this.capacity)
    
    if(this.status === "BUSY" && this.capable == true)
      {
        stroke('magenta')
        
        customer.beingserved = true;
        this.servingcustomer = true;
        
   line(this.location.x,this.location.y,customer.location.x,this.location.y)
   line(customer.location.x,customer.location.y,customer.location.x,this.location.y)
        
        if(this.horizontal == true)
          {
    //       print("trying to go horizontal!")
        if(this.location.x < customer.location.x)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.location.x)
      this.location.x = this.location.x - this.speed
      
       //check within a range to prevent driver from being stuck!
      if(this.location.x > customer.location.x - 10 && this.location.x < customer.location.x || this.location.x < customer.location.x + 10 && this.location.x > customer.location.x) 
        {
          this.location.x = customer.location.x
        }
            
      if(this.location.x == customer.location.x)
         this.horizontal = false
       
          }
        
        else if (this.horizontal == false)
          {
      //      print("trying to go vertical!")
            
        if(this.location.y < customer.location.y)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.location.y)
      this.location.y = this.location.y - this.speed
            
        //check within a range to prevent driver from being stuck!
      if(this.location.y > customer.location.y - 10 && this.location.y < customer.location.y || this.location.y < customer.location.y + 10 && this.location.y > customer.location.y) 
        {
          this.location.y = customer.location.y
        }
      
            
            
          if(this.location.y == customer.location.y)
            {
      //        print("i made it to the customer!")
              this.horizontal = true
              this.status = "CARRYING"
              
              customer.displayfinallocation()
              
          //    this.status = "AVAILABLE";
          //    this.currentRide = null; 
            }
            
          }
        
      }
    else if (this.status == "BUSY" && this.capable == false)
      {
        // print("im tired")
        // print(this.capable)
        // print(this.capacity)
        
        this.horizontal = true
        this.status = "RESTING" //or resting or available
        
        customer.beingserved = false;
        this.servingcustomer = false;
        
        this.currentRide = null;
        
     //   customer.currentcustomer = customer.currentcustomer
        
        
        
//           if(customer.refreshing == false)
//                 {
//             print("i delivered the customer to its final location!")
//               print("my driver id:")
//               print(this.id)
//         //      print(customer.currentcustomer)
//             print("-----")
//                 }
              
//               customer.beingserved = false;
//               this.servingcustomer = false;
              
//               this.horizontal = true
//               this.status = "AVAILABLE"; //resting or available
              
//           listc.customermovethroughlist() //calllist()
          
              
//           this.currentRide = null;
      
              
//             if(customer.firsttestcustomer == true)
//               customer.firsttestcustomer = false //''
              
              
              
//             if(customer.refreshing == true)
//               {
//                 customer.refreshing = false
//                 print("refreshing done!")
//               }
            
              
//               this.status = "RESTING"
              
        
        
      }
    
    
    
    
    
    
    
    if(this.status === "CARRYING") //has customer
      {
        
        customer.displayfinallocation()
        customer.beingserved = true;
        this.servingcustomer = true;
        
       stroke('orange')
        

    line(this.location.x,this.location.y,customer.finallocation.fx,this.location.y)
    line(customer.finallocation.fx,customer.finallocation.fy,customer.finallocation.fx,this.location.y)
        
        
        if(this.horizontal == true)
          {
          //  print("trying to go horizontal!")
        if(this.location.x < customer.finallocation.fx)
      this.location.x = this.location.x + this.speed
        if(this.location.x > customer.finallocation.fx)
      this.location.x = this.location.x - this.speed
            
           //check within a range to prevent driver from being stuck!
      if(this.location.x > customer.finallocation.fx - 10 && this.location.x < customer.finallocation.fx || this.location.x < customer.finallocation.fx + 10 && this.location.x > customer.finallocation.fx) 
        {
          this.location.x = customer.finallocation.fx
        }
            
            
      if(this.location.x == customer.finallocation.fx)
         this.horizontal = false
            
            
          }
        
        else if (this.horizontal == false)
          {
           // print("trying to go vertical!")
            
        if(this.location.y < customer.finallocation.fy)
      this.location.y = this.location.y + this.speed
  
        if(this.location.y > customer.finallocation.fy)
      this.location.y = this.location.y - this.speed
            
             //check within a range to prevent driver from being stuck!
      if(this.location.y > customer.finallocation.fy - 10 && this.location.y < customer.finallocation.fy || this.location.y < customer.finallocation.fy + 10 && this.location.y > customer.finallocation.fy) 
        {
          this.location.y = customer.finallocation.fy
        }
      
            
            
          if(this.location.y == customer.finallocation.fy)
            {
              if(customer.refreshing == false)
                {
            print("i delivered the customer to its final location!")
              print("my driver id:")
              print(this.id)
        //      print(customer.currentcustomer)
            print("-----")
                }
              
              customer.beingserved = false;
              this.servingcustomer = false;
              
              this.horizontal = true
              this.status = "AVAILABLE"; //resting or available
              
          listc.customermovethroughlist() //calllist()
          
              
          this.currentRide = null;
      
              
            if(customer.firsttestcustomer == true)
              customer.firsttestcustomer = false //''
              
              
              
            if(customer.refreshing == true)
              {
                customer.refreshing = false
                print("refreshing done!")
              }
            
              
              this.status = "RESTING"
              
            }
            
          }
        
      }
    
    
    if(this.status === "AVAILABLE") //slowly return home, look for future customers
      {
        
     if(this.horizontal == true)
       {
         if(this.location.x < this.homelocation.x)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > this.homelocation.x)
        this.location.x = this.location.x - this.speed/2
         
         if(this.location.x == this.homelocation.x)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < this.homelocation.y)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > this.homelocation.y)
       this.location.y = this.location.y - this.speed/2
          
          if(this.location.y == this.homelocation.y)
          this.horizontal = true
        }
        
          if(listd.currentdriver.currentRide !== listc.final && customer.currentcustomer !== null) //helps to assign and reassign a customer
           {
         listd.currentdriver.assignRide(customer,500)
           }

        
//         if(listd.currentdriver.currentRide !== listc.final && customer.currentcustomer !== null && this.capacity >= customer.currentcustomer.capacityneeded) //helps to assign and reassign a customer
//           {
//         listd.currentdriver.assignRide(customer,500)
//           }
//         else
//           {
//             print(listd.currentdriver)
//             print("i can't serve the next customer! (waiting for another driver)")
            
//             if(listd.final.status === "AVAILABLE")
//             listd.final.assignRide(customer,500)
            
//           }
        
        
        
        
      }
  
    
  }
  
  alternatemovedriver()
  {
      if(this.status === "RESTING") //slowly return home and wait
      {
        this.currentRide = null
        this.servingcustomer = false;
        
     if(this.horizontal == true)
       {
         if(this.location.x < this.homelocation.x)
        this.location.x = this.location.x + this.speed/2
         if(this.location.x > this.homelocation.x)
        this.location.x = this.location.x - this.speed/2
         
         
      //check within a range to prevent driver from being stuck!
      if(this.location.x > this.homelocation.x - 10 && this.location.x < this.homelocation.x || this.location.x < this.homelocation.x + 10 && this.location.x > this.homelocation.x) 
        {
          this.location.x = this.homelocation.x
        }
         
         
         if(this.location.x == this.homelocation.x)
         this.horizontal = false
       }
        
      if(this.horizontal == false)
        {
          if(this.location.y < this.homelocation.y)
       this.location.y = this.location.y + this.speed/2
          if(this.location.y > this.homelocation.y)
       this.location.y = this.location.y - this.speed/2
          
          //check within a range to prevent driver from being stuck!
      if(this.location.y > this.homelocation.y - 10 && this.location.y < this.homelocation.y || this.location.y < this.homelocation.y + 10 && this.location.y > this.homelocation.y) 
        {
          this.location.y = this.homelocation.y
        }
          
          
          
          if(this.location.y == this.homelocation.y)
          this.horizontal = true
        }
        
        
      }
    
    
  }

  update() { //wogw3eo
    if (this.status === "BUSY") 
    {
      this.busyTimer--; //this.busyTimer = this.busyTimer - 1
   //  this.busyTimer = this.busyTimer - (this.speed-1); //()
      if (this.busyTimer <= 0) 
      {
      //  this.status = "RESTING";
      //  this.currentRide = null;  
        
        this.horizontal = true
        this.status = "RESTING" //or resting or available
        
        customer.beingserved = false;
        this.servingcustomer = false;
        
        this.currentRide = null;
      }
    }
    
    if(this.status === "RESTING")
      {
        if(this.location.x == this.homelocation.x && this.location.y == this.homelocation.y)
          {
         this.restingTimer = this.restingTimer - (this.speed-1); //this.restingTimer = this.restingTimer - 1; (or this.restingTimer --)
         //   print(this.speed-1)
            text(this.restingTimer,this.homelocation.x,this.homelocation.y + 20)
          }
        
        if(this.restingTimer <= 0)
          {
            this.status = "AVAILABLE"
            this.restingTimer = round(random(90,500));
            
          } 
        
      }
  }

  display() 
  {
    if(this.status === "AVAILABLE")
      fill("green")
    if(this.status === "BUSY")
      fill("red")
    if(this.status === "CARRYING")
      fill("orange")
    if(this.status === "RESTING")
      fill("black")
    
    ellipse(this.location.x, this.location.y, 22);
    fill(0);
    textSize(10);
    textAlign(CENTER);
    
    fill(100,100,100)
    text(this.id,this.location.x,this.location.y + 3)
    
   //// textSize(8)
   //// text(this.capable,this.location.x,this.location.y)
    
    if(this.capable == false)
      {
    fill(200,0,0)
    text(this.capable,this.location.x+20,this.location.y)
      }
    
    if(this.id == 1 && this.canholdanycustomer == true) //mark the main driver
      {
      fill(200,100,30)
   // fill(255,255,0)
    text("''",this.location.x+0,this.location.y-5)
      }
    
    
    fill(100,100,100)
    
  }
  
  drawhome() //draw a dot that represents home
  {
    
    if(this.drawnhome == false)
      {
    if(this.id == 1)
      {
        this.homelocation.x = 40
        this.homelocation.y = 80
      }
    else if(this.id == 2)
      {
        this.homelocation.x = 40*12
        this.homelocation.y = 80
      }
    else if(this.id > 2) //3 or above!
      {
        this.homelocation.x = 40*round(random(1,12))
        this.homelocation.y = 40*round(random(2,9))
      }
        
      this.drawnhome = true;
      }
    
    
    fill(255,0,0)
    circle(this.homelocation.x,this.homelocation.y,5) //40 each
    fill(0)
    textSize(10)
   // text("Home",28,65)
    
    if(this.id == 1)
    text("Home",this.homelocation.x-12,this.homelocation.y - 15)
    else
    text("Home",this.homelocation.x-3,this.homelocation.y - 15)
    
    
    text(this.id,this.homelocation.x-12+30,this.homelocation.y - 15)
    
    if(this.id == 2 || this.id == 1)
      text("'",this.homelocation.x-12+36,this.homelocation.y - 15)
    
  }
  
  starthome() //start the driver at home
  {
    
    if(this.id == 1)
      {
        this.location.x = 40 //40*1
        this.location.y = 80 //40*2
      }
    else if(this.id == 2)
      {
        this.location.x = 40*12
        this.location.y = 80
      }
    else if (this.id > 2) // 3 or above!
      {
        this.location.x = this.homelocation.x
        this.location.y = this.homelocation.y
      }
    
    
    
  }
  
  
  updatespeed()
  {
  //  print(this.location.x)
   // print(this.speed)
    
 //   if(simulation.simulationspeed == 1)
  //  this.speed = 2
    
 //   if(simulation.simulationspeed == 2)
  //  this.speed = 3
    
    for(i = 0; i<=10; i++)
      {
        if(simulation.simulationspeed == i) //numbers!
          this.speed = i+1;
      }
    
  //  if(simulation.simulationspeed == 1)
      
    
   // if(this.speed >= 10)
   // this.speed = 2
    
  }
  
  
  checkforcapability() //checks to see if the driver is currently capable of serving the customer (capacity)
  {
    //  print("driver id:")
    //  print(this.id)
   //  print("this.capacity")
   //   print(this.capacity)
   // // print("am i capable of dealing with the customer?")
   // // print(this.capable)
    
  //  print("00000000000000000000000")
    
    
  if(customer.lastcustomerserved == false) //not the last one on the list? (prevents null)
  {
        
    //  print("i am running this")
    
    if(customer.refreshing == false)
   {
     
    if(this.capacity >= customer.currentcustomerdisplaynode.capacityneeded)
      {
        this.capable = true;
      }
    else if(this.capacity < customer.currentcustomerdisplaynode.capacityneeded)
      {
        this.capable = false;
      }
     
   }
    
    
    
  }
    
    
  if(customer.lastcustomerserved == true && customer.doneservingallcustomer == false) //is the last customer being served?
    {
      
      if(customer.refreshing == false)
      {
        
      if(this.capacity >= customer.currentcustomer.capacityneeded)
      {
        this.capable = true;
      }
    else if(this.capacity < customer.currentcustomer.capacityneeded)
      {
        this.capable = false;
      }
        
        
      }
      
    }
 
    
    
    if(customer.refreshing == true)
      {
        this.capable = true
      }
    
    
    
  }
  
  
  
  
  
}
































