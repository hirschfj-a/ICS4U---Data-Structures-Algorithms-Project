//--------LINKEDLISTS----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class LinkedList
  {
    
    constructor() 
  {
    //General:
    this.head = null;
    this.size = 1;
    
    this.final = null;
    
    
    
    //Drivers:
    this.currentdriver = null; //let this be "curr" for the driver's list
    
    this.doneassigningfirstcapacity = false;
 //   this.doneassigningallcapacities = false;
    
    
  }
    
    
  insertcustomer(data) 
  { //ADD LINKS
    print("hi!")
    let node = new Node(this.size++); //this.size++? (The node (or information of the customer) exists in the list!)
      if(this.head === null)
        {
          this.head = node;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          customer.currentcustomer = this.head; //START LIST BY SHOWING FIRST DELIVERY NEEDED (in linked list)!
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = node;
          
        }
  }
    
  insertdriver(data) 
  { //ADD LINKS
  //  print("hi!")
     driver = new Driver(this.size++); //this.size++? (Creates a copy of driver!)
      if(this.head === null)
        {
          this.head = driver;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = driver;
          
        }
  }
    
  search(predicate) // STUDENTS IMPLEMENT
   {
  let curr = this.head;
  while (curr !== null) 
  {
  //  print(curr)
    if (predicate === curr.id) 
    {
      print(curr)
      return curr;
    }
    curr = curr.next;
  }
  print("Could not find that node!")
     
  return null;
}
    
    
  remove(n) //remove(n) OR delete(data)
   {
      print("-----------------")
       print("REMOVING Link #:")
       print(n) //data or 'n'
       print("-----------------")
      
       let prev = null;
       let curr = this.head;
       while(curr.id !== n)//keep moving if not target link
         {
           prev = curr;
           curr = curr.next;
           if(curr === null) //reached end of list?
             {
               return; //end
             }
         }
       prev.next = curr.next //(removes link)
   }
    
    
displaylist()
  {
    print("-----------------------------")
      print("NOW DISPLAYING!:")
      print("head:")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null && curr.next !== null)
        {
          print(curr)
          curr = curr.next;
          
        }
    
    //runs when the while loop is false (last one):
       print(curr)
       this.final = curr
       curr = curr.next;
       
    print("final:")
     print(this.final)
      
      
      print("-----------------------------")
    
  }
    
    
 //  traverse(callback) 
 // {
 //     // STUDENTS IMPLEMENT
 // }
    
    
    
drivercommands() //traverses through the list (for drivers)
  {
   this.currentdriver = this.head; //act as curr
    
    while(this.currentdriver !== null)
        {
          //Create each driver's home:
          this.currentdriver.drawhome()
          
          //Set each driver home:
          if(this.currentdriver.onlyonce == true)
            {
              this.currentdriver.starthome()
              this.currentdriver.onlyonce = false
            }
          
       //   FIX! (FIXED!)
      
        
  
          //Create driver #1's capacity (allow driver #1 to be able to hold any customer)
          if(this.doneassigningfirstcapacity == false && this.currentdriver.canholdanycustomer == false)
            {
              this.currentdriver.capacity = 5; //final driver can hold the max capacity (so all customers have a possible driver)
              this.currentdriver.canholdanycustomer = true
              this.doneassigningfirstcapacity = true
            }
           
           
           //Create all other driver's capacities
          if(this.currentdriver.capacity === undefined && this.doneassigningfirstcapacity == true && this.currentdriver.canholdanycustomer == false) //if(this.currentdriver.capacity != 3 
            {
     //  this.currentdriver.capacity = 3; //ex. other drivers can only hold requests with a needed capacity of 3 or lower
              this.currentdriver.capacity = round(random(3,4));
            }
          
      //all customers will now have a driver that exists for them (a driver can now hold a capacity)!
          
        //  print(this.doneassigningallcapacities)
          
          
          this.currentdriver.updatespeed()
          
          if(customer.firsttestcustomer == false)
          this.currentdriver.checkforcapability()
          
         // this.currentdriver.drawhome() (moved above)
          this.currentdriver.display()
          this.currentdriver.update()
          
          this.currentdriver.alternatemovedriver()
          
          if(customer.beingserved == true && this.currentdriver.servingcustomer == true)
            {
          this.currentdriver.movedriver()
         //    print(this.currentdriver.id)
          //   print("i am running")
            }
          
          if(customer.beingserved == false && this.currentdriver.servingcustomer == false && this.currentdriver.status === "AVAILABLE") //only allows one driver at a time 
            {
          customer.beingserved = true
          this.currentdriver.servingcustomer = true
         //     print("i ran")
            }
          
          this.currentdriver = this.currentdriver.next; //cycles through each driver
        }
          
    
  }
    
    
    
    
customermovethroughlist() //traverse through the list for customers (the requests)
  {
    
    while(listd.currentdriver.currentRide !== null && listd.currentdriver.status == "AVAILABLE")
      {
    //    print(listd.currentdriver.currentRide)
     //   print(listd.currentdriver.status)
        
     //   if(listd.currentdriver.capacity >= customer.currentcustomer.capacityneeded)
            
            
    customer.processcoordinates()
  
    
    if(customer.lastcustomerserved == true) //FINAL CUSTOMER FULLY SERVED (the drivers will see this variable is true and will know that they have served all of the customers)
      {
        customer.doneservingallcustomers = true;
        
        print("----------------------------- ")
        print("i delivered the final customer to its final location!!!")
        print("my driver id:")
        print(listd.currentdriver.id)
        print("----------------------------- ")
      }
        

   if(customer.currentcustomer !== this.final)
   {
    customer.currentcustomer = customer.currentcustomer.next;
     
     if(customer.currentcustomerdisplaynode !== null)
     customer.currentcustomerdisplaynode = customer.currentcustomerdisplaynode.next;
     
     if(customer.currentcustomerdisplaynode === null)
     customer.currentcustomerdisplaynode = this.head;
     
    }
  else //customer.currentcustomer === this.final
   {  
     if(customer.lastcustomerserved == true) //if in the process of serving the last request, prepare the next request to become null
      customer.currentcustomer = null
     
     
     if(customer.lastcustomerserved == false) //check to see if the request that is about to be served is the final request on the list
       {
       customer.currentcustomer = customer.currentcustomer //do nothing (don't go ahead)
       customer.lastcustomerserved = true //mark it so that the drivers know they will be serving the last request for next delivery
       }
   }
        
   listd.currentdriver.assignRide(customer,500) //will go to the customer! (500 or 90 for testing)     
    
        
        
      }
      print("-----------------------------") 
  }
    
    
    
    
    
    
    
    
    
    
    
  }











//     if(2 == 1)
//       {
//         print(1)
        
        
//       }
    












