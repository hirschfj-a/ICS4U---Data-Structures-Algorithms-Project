//--------LINKEDLISTS----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class LinkedList
  {
    
    constructor() 
  {
    //General:
    this.head = null;
    this.size = 1;
    
    this.final = null;
    
    //Event Nodes:
    this.currenteventnode = null; //let this be "curr" for the event node list
    this.Y = 1; //tells which step that the information in the log is in (can be used as a multipler for y to help display events from linked list)
    this.savedY = 0; //saves the Y value for the previous y
    //this.startcleardisplay = false; 
    
    
    
    
    //Drivers:
    this.currentdriver = null; //let this be "curr" for the driver's list
    //customer.beingserved helps to determine if a driver is capable of serving the customer (on customer)
    this.driverwithgoodmood = false; //checks to see if there is an available driver that has a good mood
    this.driverwithmatchingmusic = false; //checks to see if there is an available driver that has matching music!
    
    this.driverthatisbusy = false; //checks to see if a driver is busy! (can help log overtakes)
    
    this.amountofdrivers = 2; //checks to see the amount of drivers in the list!
    
   // this.drivergoingvertical = false; 
    
    
    this.doneassigningfirstcapacity = false;
 //   this.doneassigningallcapacities = false;
    
    
    
    this.knownclosestdistance = 100000000; //make the known closest distance a far value
    
   // this.foundclosestdistance = false;
   // this.foundpossibleclosestdistance = false;
    
    this.prioritizedistance = true; //prioritize distance? (helps to allow the simulation to continue if distance stops working)
    
    this.closestdrivermarkid = 0;
    
    
  }
    
    
  insertloginformation()
    {
     // if(customer.refreshing == false && listd.currentdriver.broadcastmyevent != 5)
     //   {
      
    //  print("inserting log information!")
      let eventnode = new EventNode(this.size++)
        if(this.head === null)
          {
            this.head = eventnode
            eventnode.firstevent()
            
        //    eventnode.y = 40*(this.size-1)
        //    eventnode.create()
          }
        else
          {
            
          let curr = this.head;
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          //on the last node? (curr.next === null)
            
          curr.next = eventnode;
            
            
            eventnode.driverid = listd.currentdriver.id
            eventnode.customerrequestid = customer.currentcustomerdisplay //current customer id
            eventnode.simulationspeedrecorded = simulation.simulationspeed
            eventnode.driveramountrecorded = listd.amountofdrivers
            
          //  eventnode.customerratingrecorded = customer.customerrating //customer rating
            
            
             if(listd.currentdriver.broadcastmyevent == 1) //saw customer and is serving
              { 
                eventnode.eventtype = 1;
              }
            if(listd.currentdriver.broadcastmyevent == 2) //served customer
              { 
                eventnode.eventtype = 2;
              }
              if(listd.currentdriver.broadcastmyevent == 3) //overridden match
              { 
                eventnode.eventtype = 3;
              }
            if(listd.currentdriver.broadcastmyevent == 4) //expired match
              { 
                eventnode.eventtype = 4;
              }
            
            if(listd.currentdriver.broadcastmyevent == 5) //simulation refresh
              { 
                eventnode.eventtype = 5;
              }
            
            
            if(eventnode.eventtype == 2) //served customer
              {
                 print("recorded customer time elapsed:")
                 print(customer.timeelapsed)
                 print("recorded customer rating (0-5):")
                 print(customer.customerrating)
                
                
                
           //     print("recorded driver amount:")
           //     print(listd.amountofdrivers)
                
             //   print(eventnode.customertimeelapsed)
                
            //    customer.timeelapsed = eventnode.customertimeelapsed;
                eventnode.customertimeelapsed = customer.timeelapsed //show the time elapsed in the full log
                eventnode.drivergoodmoodrecorded = listd.currentdriver.goodmood
                eventnode.drivermusicmatchrecorded = listd.currentdriver.musicmatch
                
                
                eventnode.customerratingrecorded = customer.customerrating //customer rating
            ///    eventnode.driveramountrecorded = listd.amountofdrivers
                
            //    print(eventnode.customertimeelapsed)
              }
            
            if(eventnode.eventtype == 5) //done serving all customers (refreshing)
              {
                eventnode.overallgoodratingsrecorded = customer.overallgoodrating
              }
            
         //   print(this.Y)
            
            if(this.Y == 1)
              {
            eventnode.y = 40
            this.savedY = eventnode.y
              }
            else
              {
            eventnode.y = this.savedY + 16 //12 or 13 or 16
            this.savedY = eventnode.y
              }
            
            this.Y = this.Y + 1
            
            
         //   print(this.Y)
            
//             if(this.Y == 1)
//             eventnode.y = 40*this.Y
//             else
//             eventnode.y = 40*this.Y*0.65
            
          //  if(eventnode.id == 2) first event being displayed
          //  eventnode.y = 40*(this.size-2)
            
          //  if(eventnode.id > 2)
          //  eventnode.y = 40+(8*(this.size-3))
            
            
            
            
            
          //  eventnode.create()
         //  listlog.displaylist() //temporary for testing
            
          }
      
      
      //  }
    }
    
    
  insertcustomer(data) 
  { //ADD LINKS
    print("hi!")
    let node = new Node(this.size++); //this.size++? (The node (or information of the customer) exists in the list!)
      if(this.head === null)
        {
          this.head = node;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          customer.currentcustomer = this.head; //START LIST BY SHOWING FIRST DELIVERY NEEDED (in linked list)!
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = node;
          
        }
  }
    
  insertdriver(data) 
  { //ADD LINKS
  //  print("hi!")
     driver = new Driver(this.size++); //this.size++? (Creates a copy of driver!)
      if(this.head === null)
        {
          this.head = driver;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = driver;
          
        }
  }
    
  search(predicate) // STUDENTS IMPLEMENT
   {
  let curr = this.head;
  while (curr !== null) 
  {
  //  print(curr)
    if (predicate === curr.id) 
    {
      print(curr)
      return curr;
    }
    curr = curr.next;
  }
  print("Could not find that node!")
     
  return null;
}
    
    
  remove(n) //remove(n) OR delete(data)
   {
      print("-----------------")
       print("REMOVING Link #:")
       print(n) //data or 'n'
       print("-----------------")
      
       let prev = null;
       let curr = this.head;
       while(curr.id !== n)//keep moving if not target link
         {
           prev = curr;
           curr = curr.next;
           if(curr === null) //reached end of list?
             {
               return; //end
             }
         }
       prev.next = curr.next //(removes link)
   }
    
    
displaylist()
  {
    print("-----------------------------")
      print("NOW DISPLAYING!:")
      print("head:")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null && curr.next !== null)
        {
          print(curr)
          curr = curr.next;
          
        }
    
    //runs when the while loop is false (last one):
       print(curr)
       this.final = curr
       curr = curr.next;
       
    print("final:")
     print(this.final)
      
      
      print("-----------------------------")
    
  }
    
    
 //  traverse(callback) 
 // {
 //     // STUDENTS IMPLEMENT
 // }
    
eventnodecommands() //traverses through the log list
    {
      this.currenteventnode = this.head; //act as curr
      
      while(this.currenteventnode !== null)
        {
          this.currenteventnode.create()
          
          
          this.currenteventnode = this.currenteventnode.next; //cycles through each event node
        }
      
      
      
    }
    
cleardisplay() //for logs
    {
    //  print("finfq")
      
      for(i = 2; i<=listlog.size+5; i++) //refreshes the log
          {
       listlog.remove(i)
          }
      
        listlog.size = 2;
        listlog.Y = 1;
    }
    
drivercommands() //traverses through the list (for drivers)
  {
   this.currentdriver = this.head; //act as curr
    
    while(this.currentdriver !== null)
        {
          //Create each driver's home:
          this.currentdriver.drawhome()
          
          //Set each driver home:
          if(this.currentdriver.onlyonce == true)
            {
              this.currentdriver.starthome()
              this.currentdriver.onlyonce = false
            }
          
       //   FIX! (FIXED!)
      
        
  
          //Create driver #1's capacity and set most ideal amenities (allow driver #1 to be able to hold any customer)
          if(this.doneassigningfirstcapacity == false && this.currentdriver.canholdanycustomer == false)
            {
              this.currentdriver.capacity = 5; //final driver can hold the max capacity (so all customers have a possible driver)
              this.currentdriver.goodmoodset = 1; //good mood!
              this.currentdriver.favouritemusic = 0; //will love all music!
              
              this.currentdriver.canholdanycustomer = true
              this.doneassigningfirstcapacity = true
            }
           
          /// FIX THE CAPACITY HERE!
             
           //Create all other driver's capacities
          if(this.currentdriver.capacity === undefined && this.currentdriver.goodmoodset === undefined && this.currentdriver.favouritemusic === undefined && this.doneassigningfirstcapacity == true && this.currentdriver.canholdanycustomer == false) //if(this.currentdriver.capacity != 3 
            {
            //  print("oinfonfiqponfqi")
             // print
     //  this.currentdriver.capacity = 3; //ex. other drivers can only hold requests with a needed capacity of 3 or lower
              
              this.currentdriver.capacitynormaldistribution = round(random(0,1))
              
              if(this.currentdriver.capacitynormaldistribution == 0)
              this.currentdriver.capacity = round(random(3,4))
              
              else if(this.currentdriver.capacitynormaldistribution == 1)
              this.currentdriver.capacity = 5
              
              
              
              this.currentdriver.goodmoodset = round(random(0,1))
              this.currentdriver.favouritemusic = round(random(1,5))
            }
          
      //all customers will now have a driver that exists for them (a driver can now hold a capacity)!
          
        //  print(this.doneassigningallcapacities)
          
          
          this.currentdriver.updatespeed()
          
          if(customer.firsttestcustomer == false) //not the first test customer? (the customer id != 0)
            {
          this.currentdriver.checkforcapability()
          this.currentdriver.checkforidealconditions()
            }
          
         // this.currentdriver.drawhome() (moved above)
          this.currentdriver.display()
          this.currentdriver.update()
        //  this.currentdriver.dodistance()
          
          this.currentdriver.alternatemovedriver() //movement for when the driver is resting
          
        //  print(customer.beingserved)
          
          
          if(customer.beingserved == true && this.currentdriver.servingcustomer == true)
            {
          this.currentdriver.movedriver() //movement for when the driver is not resting
              
         //    print(this.currentdriver.id)
          //   print("i am running")
            }
          
          if(customer.beingserved == false && this.currentdriver.servingcustomer == false && this.currentdriver.status === "AVAILABLE") //only allows one driver at a time to serve the customer (this sees that the customer is not being served and nobody else is serving the customer.)
            {
          customer.beingserved = true
          this.currentdriver.servingcustomer = true
         //     print("i ran")
            }
          
          
          ///for preventing the driver from accidentally going when they are not supposed to
          if(customer.beingserved == false && this.currentdriver.servingcustomer == true)
           {
             this.currentdriver.servingcustomer = false;
             
             if(this.currentdriver.status == "BUSY")
               this.currentdriver.status = "RESTING"
             
             if(this.currentdriver.status == "CARRYING")
               this.currentdriver.status = "RESTING"
             
             
           }
          
          
    // print("driver with good mood")
    // print(this.driverwithgoodmood)
    // print("driver with matching music")
    // print(this.driverwithmatchingmusic)
          
          
          
          this.currentdriver = this.currentdriver.next; //cycles through each driver
        }
          
    
  }
    
    
    
    
customermovethroughlist() //traverse through the list for customers (the requests)
  {
    
    while(listd.currentdriver.currentRide !== null && listd.currentdriver.status == "AVAILABLE")
      {
    //    print(listd.currentdriver.currentRide)
     //   print(listd.currentdriver.status)
        
     //   if(listd.currentdriver.capacity >= customer.currentcustomer.capacityneeded)
            
            
    customer.processcoordinates()
  
    
    if(customer.lastcustomerserved == true) //FINAL CUSTOMER FULLY SERVED (the drivers will see this variable is true and will know that they have served all of the customers)
      {
        customer.doneservingallcustomers = true;
        
        print("----------------------------- ")
        print("i delivered the final customer to its final location!!!")
        print("my driver id:")
        print(listd.currentdriver.id)
        print("----------------------------- ")
      }
        

   if(customer.currentcustomer !== this.final)
   {
    customer.currentcustomer = customer.currentcustomer.next;
     
     if(customer.currentcustomerdisplaynode !== null)
     customer.currentcustomerdisplaynode = customer.currentcustomerdisplaynode.next;
     
     if(customer.currentcustomerdisplaynode === null)
     customer.currentcustomerdisplaynode = this.head;
     
    }
  else //customer.currentcustomer === this.final
   {  
     if(customer.lastcustomerserved == true) //if in the process of serving the last request, prepare the next request to become null
      customer.currentcustomer = null
     
     
     if(customer.lastcustomerserved == false) //check to see if the request that is about to be served is the final request on the list
       {
       customer.currentcustomer = customer.currentcustomer //do nothing (don't go ahead)
       customer.lastcustomerserved = true //mark it so that the drivers know they will be serving the last request for next delivery
       }
   }
        
   listd.currentdriver.assignRide(customer,500*listd.currentdriver.busymultiply) //will go to the customer! (500 or 90 for testing)     
    
        
        
      }
      print("-----------------------------") 
  }
    
    
    
    
    
    
    
    
    
    
    
  }











//     if(2 == 1)
//       {
//         print(1)
        
        
//       }
    












