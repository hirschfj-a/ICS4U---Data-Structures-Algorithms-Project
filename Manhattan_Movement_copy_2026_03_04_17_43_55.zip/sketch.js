//Manhatten Movement copy - Journey

let courier;
let delivery;


function setup() {
  createCanvas(600, 400);
  
  courier = new Courier(80, 120); //40 each block
  delivery = new DeliveryRequest(440, 320);
  
  list = new List();
  
  
  for(i = 1; i<=4; i++)
    {
  list.addLink()
    }
  
   list.displayList();
  list.movethroughList()
  
  
  courier.assignDelivery(delivery);
}





function draw() 
{
  background(40);
  
  drawGrid(40);
  
  delivery.display();
  
  courier.update();
  courier.display();
}

function drawGrid(size) {
  stroke(60);
  for (let x = 0; x < width; x += size) {
    line(x, 0, x, height);
  }
  for (let y = 0; y < height; y += size) {
    line(0, y, width, y);
  }
}








class Courier 
{ //driver
  constructor(x, y) {
    this.position = createVector(x, y);
    this.speed = 2;
    this.state = "IDLE"; // IDLE, EN_ROUTE, DELIVERED
    this.target = null;
  }

  assignDelivery(delivery) {
    this.target = delivery;
    this.state = "EN_ROUTE";
  }

  update() {
    if (this.state === "EN_ROUTE") {
      this.moveManhattan();
      
      if (this.atTarget()) {   //AT THE TARGET! <-----
        this.state = "DELIVERED";
        delivery.changedeliveryposition2()
       //   delivery.changedeliveryposition() //this one is for generating a random position
    //    this.position = (x,y)
      }
    }
  }

  moveManhattan() {
    if (!this.target) return;

    let targetX = this.target.position.x;
    let targetY = this.target.position.y;

    // Move horizontally first (yes)
    if (this.position.x !== targetX) {
      let dir = Math.sign(targetX - this.position.x); 
      this.position.x += dir * this.speed;
    }
    // Then move vertically
    else if (this.position.y !== targetY) {
      let dir = Math.sign(targetY - this.position.y);
      this.position.y += dir * this.speed;
    }
  }

  atTarget() {
    return (
      this.position.x === this.target.position.x &&
      this.position.y === this.target.position.y
    );
  }

  display() {
    fill(
      this.state === "IDLE" ? "orange" :
      this.state === "EN_ROUTE" ? "orange" :
      80
    );
    
    noStroke();
    ellipse(this.position.x, this.position.y, 20);
    
    fill(180);
    textAlign(CENTER);
    text(this.state, this.position.x, this.position.y - 20);
  }
}





class DeliveryRequest 
{
  constructor(x, y, currentdelivery) {
    this.position = createVector(x, y);
    this.number = createVector(x,y); //this.number.x and this.number.y ---> used for knowing where target is!
    this.currentdelivery = null //current delivery, used as a curr when the driver follows linked list
  }

  display() {
    fill(100,255,100);
    rectMode(CENTER);
    noStroke();
    rect(this.position.x, this.position.y, 20, 20);
  }
  
//   changedeliveryposition()
//   {
//     let randomnumberx = round(random(0,13)) //can possibly implement linked list if wanted (changedeliveryposition2)
//     let randomnumbery = round(random(0,10))
//     print("delivery new pos:")
//     print(randomnumberx)
//     print(randomnumbery)
    
//     for(let i = 0; i<=13; i++)
//     {
//     if(randomnumberx == i)
//     this.position.x = 40*i
      
//     if(randomnumbery == i)
//     this.position.y = 40*i
    
//     }
    
    
//   //  manhatten.state = "EN_ROUTE"
    
//     courier.assignDelivery(delivery);
//   //  courier.moveManhattan()
    
        
//     //this.position.y = 120 || 140 
//    // this.position.x = 40 || 40*2 || 40*3 || 40*4
        
//   //  this.position.x = 80+40 //40 each block!
//   //  this.position.y = 120
    
//   }
  
  changedeliveryposition2()
  {
    list.movethroughList()
  }
  
  
  
}




class Link
  {
    constructor(_id,pos)
    {
      this.next = null;
      this.id = _id;
      this.pos = createVector(round(random(0,13)),round(random(0,10)))
    }
    
    display()
    {
      console.log(this.id);
      
    }
    
  }



class List
  {
    constructor()
    {
      this.head = null;
      this.size = 1;
    }
    
    addLink()
    {
   //   print("hi")
      let link = new Link(this.size++); //this.size++?
      if(this.head === null)
        {
          this.head = link;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          delivery.currentdelivery = this.head //START LIST BY SHOWING FIRST DELIVERY NEEDED!
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = link;
          
        }
    }
    
    displayList()
    {
      print("hi!")
      
     print("-----------------------------")
      print("NOW DISPLAYING:")
      print("head:")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null)
        {
          print(curr)
          curr = curr.next;
        }
      
      print("-----------------------------")
      
    }
    
    movethroughList()
    { 
      while(delivery.currentdelivery !== null && courier.state == "DELIVERED")
        {
          
          delivery.number.x = delivery.currentdelivery.pos.x
          delivery.number.y = delivery.currentdelivery.pos.y
          
    print("delivery new pos 2 (uses linked list):")
    print(delivery.number.x)
    print(delivery.number.y)
    
    for(let i = 0; i<=13; i++)
    {
    if(delivery.number.x == i)
    delivery.position.x = 40*i
      
    if(delivery.number.y == i)
    delivery.position.y = 40*i
    
    }
           delivery.currentdelivery = delivery.currentdelivery.next;
          
          courier.assignDelivery(delivery);
          
        }
      
      print("-----------------------------")
    }
    
  }