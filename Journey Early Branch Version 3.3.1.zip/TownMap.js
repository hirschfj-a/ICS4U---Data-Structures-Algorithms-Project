//--------TOWNMAP----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class TownMap 
{
  constructor(width, height, gridSize = 40) 
  {
    this.width = width; //520
    this.height = height; //400
    this.gridSize = gridSize;
  }

  getRandomLocation() {
    return {
      x: floor(random(this.width / this.gridSize)) * this.gridSize + this.gridSize / 2,
      y: floor(random(this.height / this.gridSize)) * this.gridSize + this.gridSize / 2
    };
  }

  getDistance(loc1, loc2) {
    return dist(loc1.x, loc1.y, loc2.x, loc2.y);
  }

  drawGrid() {
    stroke(220);
    // for (let x = 0; x < this.width; x += this.gridSize) {
    //   line(x, 0, x, this.height);
    // }
    // for (let y = 0; y < this.height; y += this.gridSize) {
    //   line(0, y, this.width, y);
    // }
    
    
    for (let x = 0; x < 520; x += this.gridSize) {
      line(x, 0, x, 400);
    }
    for (let y = 0; y < 400; y += this.gridSize) {
      line(0, y, 520, y);
    }
    
    stroke(500);
    line(520,0,520,400)
    
    fill(50)
    rect(530+100,200,200,400)
    
    fill(0)
    textSize(15) //hi!
    text("Log information:",625,20)
    
    
    fill(0)
    rect(530+100,530,200,400)
    
    textSize(14)
    text("Simulation Speed:", 520+100,400-45)
    textSize(11)
    text("(Click to increase!)", 520+100,400-30)
    textSize(19)
    text(simulation.simulationspeed, 520+100,400-10)
    
  }
}
