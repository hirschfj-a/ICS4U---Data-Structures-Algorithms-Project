class LinkedListc 
{
  constructor() 
  {
    this.head = null;
    this.size = 1;
    
    this.final = null;
  }

  insert(data) 
  { //ADD LINKS
    print("hi!")
    let node = new Node(this.size++); //this.size++? (The node (or information of the customer) exists in the list!)
      if(this.head === null)
        {
          this.head = node;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          customer.currentcustomer = this.head; //START LIST BY SHOWING FIRST DELIVERY NEEDED (in linked list)!
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = node;
          
        }
  }

  delete(data) //remove(n) OR delete(data)
  {
    //students implement
  }

  search(predicate) 
  {
    // STUDENTS IMPLEMENT
  }

  traverse(callback) 
  {
    // STUDENTS IMPLEMENT
  }
  
  
  displaylist()
  {
    print("-----------------------------")
      print("NOW DISPLAYING (FOR CUSTOMERS!):")
      print("head: (stays constant)")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null && curr.next !== null)
        {
          print(curr)
        //  print(this.id)
    //      text(this.id,100,this.id*50)
          curr = curr.next;
          
        }
    
    //runs when the while loop is false (last one):
       print(curr)
       this.final = curr
       curr = curr.next;
       
    print("final:")
     print(this.final)
      
      
      print("-----------------------------")
    
  }
  
  
  movethroughlist()
  {
   // print("test")
    
    while(listd.currentdriver.currentRide !== null && listd.currentdriver.status == "AVAILABLE")
      {
    //    print(listd.currentdriver.currentRide)
     //   print(listd.currentdriver.status)
        
        customer.number.x = customer.currentcustomer.pos.x  //position information from linked list
        customer.number.y = customer.currentcustomer.pos.y
        
        customer.finalnumber.fx = customer.currentcustomer.finalpos.x
        customer.finalnumber.fy = customer.currentcustomer.finalpos.y
        
  
        
   //     print("new position for delivery: (Uses linked list):")
  //      print("start pos:")
        print("Current customer information:")
        if(customer.currentcustomer == this.head)
        print("(This is the head of the list!)")
        
        print(customer.currentcustomer)
    //    print(driver.currentRide)
      //  print("start")
        print(customer.number.x)
        print(customer.number.y)
      //  print("end")
     //   print(customer.finalnumber.fx)
      //  print(customer.finalnumber.fy)
        
        
      
        
        
    for(let i = 0; i<=13; i++)
    {
    if(customer.number.x == i)
    customer.location.x = 40*i
      
    if(customer.number.y == i)
    customer.location.y = 40*i
      
      
    if(customer.finalnumber.fx == i)
    customer.finallocation.fx = 40*i
      
    if(customer.finalnumber.fy == i)
    customer.finallocation.fy = 40*i
      
    }
    
    if(customer.lastcustomerserved == true) //FINAL CUSTOMER FULLY SERVED
      {
        customer.doneservingallcustomers = true;
        
        print("----------------------------- ")
        print("i delivered the final customer to its final location!!!")
        print("my driver id:")
        print(listd.currentdriver.id)
        print("----------------------------- ")
      }
        

   if(customer.currentcustomer !== this.final)
   {
  //  remove(customer.currentcustomer)
  customer.currentcustomer = customer.currentcustomer.next;
    }
  else
   {
     if(customer.lastcustomerserved == true)
      customer.currentcustomer = null
     
     
     if(customer.lastcustomerserved == false)
       {
       customer.currentcustomer = customer.currentcustomer //do nothing
       customer.lastcustomerserved = true
       }
   }
        
      // if(customer.currentcustomer !== this.final && customer.firsttestcustomer == false)
        
   //  else if(customer.currentcustomer !== this.final && customer.firsttestcustomer == true)
  //  {
 //     customer.currentcustomer = customer.currentcustomer //do nothing
  //  }
        
        
        
        
  // if(customer.currentcustomer !== this.final && customer.beingserved == false && listd.currentdriver.servingcustomer == false && listd.currentdriver.status === "AVAILABLE")
    
 
  // if(customer.currentcustomer !== this.final && customer.currentcustomer !== null)
   listd.currentdriver.assignRide(customer,500) //will go to the customer! (500 or 90 for testing)
  // else if(customer.currentcustomer !== this.final && customer.currentcustomer === null)
 //    {
  //  listd.currentdriver.assignRide(customer,500)
  //   }
        
 
            
            
            
            
      
 
      }
    
   print("-----------------------------")
    
    
  }
  
  
   remove(n) //remove(n) OR delete(data)
   {
      print("-----------------")
       print("REMOVING Link #:")
       print(n) //data or 'n'
       print("-----------------")
      
       let prev = null;
       let curr = this.head;
       while(curr.id !== n)//keep moving if not target link
         {
           prev = curr;
           curr = curr.next;
           if(curr === null) //reached end of list?
             {
               return; //end
             }
         }
       prev.next = curr.next //(removes link)
   }
  
  
  
  
}













class LinkedListd
  {
    
      constructor() 
  {
    this.head = null;
    this.size = 1;
    this.currentdriver = null; //let this be "curr" for the whole list
    
    this.final = null;
  }

  insert(data) 
  { //ADD LINKS
  //  print("hi!")
     driver = new Driver(this.size++); //this.size++? (Creates a copy of driver!)
      if(this.head === null)
        {
          this.head = driver;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = driver;
          
        }
  }
    
    
    
     displaylist()
  {
    print("-----------------------------")
      print("NOW DISPLAYING (FOR DRIVERS!):")
      print("head:")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null && curr.next !== null)
        {
          print(curr)
          curr = curr.next;
          
        }
    
    //runs when the while loop is false (last one):
       print(curr)
       this.final = curr
       curr = curr.next;
       
    print("final:")
     print(this.final)
      
      
      print("-----------------------------")
    
  }
    
    drivercommands()
  {
 //   ''
   this.currentdriver = this.head; //act as curr
    
    while(this.currentdriver !== null)
        {
          if(this.currentdriver.onlyonce == true)
            {
              this.currentdriver.starthome()
              this.currentdriver.onlyonce = false
            }
          
      //    if(this.currentdriver.currentdelivery !== null && customer.beingserved == true)
       //     {
        //      this.currentdriver.status = "RESTING"
       //      this.currentdriver.currentdelivery = null
       //     }
          
          
          this.currentdriver.drawhome()
          this.currentdriver.display()
          this.currentdriver.update()
       //   this.currentdriver.movedriver() --> or possibly alternate
          this.currentdriver.alternatemovedriver()
          
          if(customer.beingserved == true && this.currentdriver.servingcustomer == true)
            {
          this.currentdriver.movedriver()
         //    print(this.currentdriver.id)
          //   print("i am running")
            }
          else
            {
       //       this.currentdriver.alternatemovedriver()
          //    print(this.currentdriver.id)
          //    print("i am running too")
            }
          
          if(customer.beingserved == false && this.currentdriver.servingcustomer == false && this.currentdriver.status === "AVAILABLE") //only allows one driver at a time 
            {
          customer.beingserved = true
          this.currentdriver.servingcustomer = true
         //     print("i ran")
            }
          
          this.currentdriver = this.currentdriver.next; //cycles through each driver
          
          
       //   print("this is running")
          
        }
          
    
  }
  
      
    
    
    
    
    
    
  }