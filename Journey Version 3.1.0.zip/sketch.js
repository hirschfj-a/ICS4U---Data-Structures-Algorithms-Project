let simulation;
let driver
let customer
//let request

function setup() {
 // print("Hello World!")
  createCanvas(520, 400); //13 squares X, 10 squares Y
  simulation = new SimulationController(width, height);
  
  frameRate(60)
  
//  print(frameCount)
  
 // driver = new Driver()
  
  customer = new Customer()
  
  listc = new LinkedListc() //the linked list for the customers will operate differently from the linked list for the drivers
  listd = new LinkedListd()
  
  
  for(i = 1; i<=4; i++)
    {
  listc.insert()
    }
  
  for(i = 1; i<=2; i++)
    {
      listd.insert()
    }
  
  listc.displaylist()
 // driver.starthome()
  customer.setcustomerstart()
 // list1.remove(2) //remove a link for testing //FIX
 // list1.displaylist()
  
 // if(driver.status === "AVAILABLE")
//  driver.assignRide(customer)
  
}

function draw() {
  background(245);
  simulation.update();
  simulation.display();
  
  listd.drivercommands()
  
 // driver.drawhome()
 // driver.display()
 // driver.update()
  
  customer.display()
  customer.managelist()
  
 // driver.movedriver()
  
  for(let i = 0; i<=13; i++)
    {
      fill('pink')
      text(i,i*39+5,10)
    }
  
  for(let i = 1; i<=10; i++)
    {
      fill('pink')
      text(i,5,i*40)
    }
  
 // print(customer.beingserved)
 //  print(customer.currentcustomer)
 // print(customer.firsttestcustomer)
  
  //print(customer.lastcustomerserved)
//  print(customer.doneservingallcustomers)
  
}

function mouseReleased() //for testing!
{
  print("Hello!")
 // customer.refreshing = true
  
//  listc.displaylist()
 // listd.displaylist()
  
  
}