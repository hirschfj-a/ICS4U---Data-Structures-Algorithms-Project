//--------CUSTOMER----------------------------------------------------------------------------------------------------------------------------------------------------------------------------


class Customer 
{
  constructor(id, location, x, y, fx, fy, passengers = 1, amenitiesRequired = []) 
  {
   // this.location = location;
    this.location = createVector(x,y)
    this.finallocation = createVector(fx,fy)
    
    this.number = createVector(x,y) //---> is used for knowing where the customer is! 
    this.finalnumber = createVector(fx,fy)
    this.currentcustomer = null //current delivery, used as a curr when the driver follows the linked list!
    this.currentcustomerdisplay = 0 //current delivery for display on the square!
    
    this.firsttestcustomer = true;
    this.beingserved = false;
    
    this.lastcustomerserved = false; //OR LASTCUSTOMERSERVING
    this.doneservingallcustomers = false;
    
    this.refreshing = false;
    
    
    
    
    this.id = id;
    this.passengers = passengers;
    this.amenitiesRequired = amenitiesRequired;

    this.requestTime = millis();
  }

  display() 
  {
    if(this.currentcustomer !== null && this.doneservingallcustomers == false && this.lastcustomerserved == false && this.currentcustomer != listc.final.id && this.currentcustomer != listc.head.id && this.firsttestcustomer != true) // other customers are being served!
      {
   //     print("22222") (print("qwoibnfgbgoiu"))
         this.currentcustomerdisplay = this.currentcustomer.id - 1
      }

    if(this.doneservingallcustomers == false && this.lastcustomerserved == true) //last customer is being served!
      {
        this.currentcustomerdisplay = listc.final.id
      }
    if(this.firsttestcustomer == true) //the test customer is being served!
      {
        this.currentcustomerdisplay = 0
      }
    if(this.currentcustomer == listc.head.id && this.doneservingallcustomers == false) //the head of the list is being served!
      {
        this.currentcustomerdisplay = 1
      }
    
    
    if(this.currentcustomerdisplay == 0 && this.firsttestcustomer != true) //check to make sure the head of the list is being served
      {
        this.currentcustomerdisplay = 1
      }
    
    if(this.beingserved == true && this.doneservingallcustomers != true && this.refreshing == false)
      { 
        
    if(this.firsttestcustomer == true)
    fill(100,100,100) //gray
        
    if(this.currentcustomerdisplay == listc.head.id && this.firsttestcustomer == false)
    fill(100,100,185) //dark blue
        
        
    if(this.firsttestcustomer == false && this.currentcustomerdisplay != listc.head.id)
    fill(100,100,255); //blue
        
        
    rectMode(CENTER);
    rect(this.location.x, this.location.y, 18, 18);

    fill(255);
    textSize(10);
    textAlign(CENTER);
   // text(this.id, this.location.x, this.location.y - 14);
    text(this.currentcustomerdisplay, this.location.x, this.location.y + 3);
      }
  }
  
  displayfinallocation()
  {
    if(this.beingserved == true && this.doneservingallcustomers == false && this.refreshing == false)
      {
    fill(0,0,200) 
    rectMode(CENTER);
    rect(this.finallocation.fx, this.finallocation.fy, 10,10)
    
   //// print(this.finallocation.fx)
    
    this.location.x = listd.currentdriver.location.x
    this.location.y = listd.currentdriver.location.y
      }
    
  }
  
  setcustomerstart()
  {
    print("----------------------------- ")
    print("Current customer information:")
    print("(This is the first test customer!)")
    print("10")
    print("8")
    
    this.location.x = 40*10
    this.location.y = 40*8
    
    this.finallocation.fx = 40*5
    this.finallocation.fy = 40*4
    
    print("----------------------------- ")
  }
  
  calllist()
  {
    listc.movethroughlist()
  }
  
  managelist()
  {
    if(this.doneservingallcustomers == true && this.lastcustomerserved == true)
      {
        
        listc.size = 2
        
        for(i = 2; i<=4; i++)
          {
       listc.remove(i)
          }
        
        for(i = 2; i<=4; i++)
         {
          listc.insert()
        }
        
        
        print("refreshed all customers! (kept the head of the list!)")
        listc.displaylist()
        
        
        this.currentcustomer = listc.head //restart back at the head and refresh!
        
        this.doneservingallcustomers = false
        this.lastcustomerserved = false
        
        this.refreshing = true;
      }
    
    
    if(this.refreshing == true)
      {
        
        rect(420,350,900,800) //width and height to cover the screen while it refreshes
        fill(0);
    textSize(14);
    textAlign(LEFT)
        text("Ride-Share Simulation", 20, 25);
        text("(refreshing...)",20+200, 25)
        
        //refreshing will be disabled by the driver!
      }
    
  }
}
