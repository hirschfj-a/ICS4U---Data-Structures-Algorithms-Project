//--------NODE----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

class Node 
{ //links or Nodes
  constructor(id) 
  { //request id
    this.id = id; //id
    this.next = null;
    this.pos = createVector(round(random(0,13)),round(random(0,10)))
    
    this.finalpos = createVector(round(random(0,13)),round(random(0,10)))
    
    
    this.capacityneeded = round(random(1,5))
    //the capacity needed shows how many passengers will enter the cars! the capacity of the car will need to be above or equal to this number to accept the request
    
  }
}