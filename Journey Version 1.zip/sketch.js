let simulation;

function setup() {
 // print("Hello World!")
  createCanvas(520, 400); //13 squares X, 10 squares Y
  simulation = new SimulationController(width, height);
  
  driver = new Driver()
  
  list1 = new LinkedList()
  
  
  for(i = 1; i<=4; i++)
    {
  list1.insert()
    }
  
  list1.displaylist()
 // list1.remove(2) //remove a link for testing //FIX
 // list1.displaylist()
  
}

function draw() {
  background(245);
  simulation.update();
  simulation.display();
  
  driver.drawhome()
 // driver.update()
}