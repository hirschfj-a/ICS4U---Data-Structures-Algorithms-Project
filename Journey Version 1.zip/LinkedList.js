class LinkedList 
{
  constructor() 
  {
    this.head = null;
    this.size = 1;
  }

  insert(data) 
  { //ADD LINKS
    print("hi!")
    let node = new Node(this.size++); //this.size++?
      if(this.head === null)
        {
          this.head = node;
        }
      else //this.head !== null
        {
          
          let curr = this.head;
          
          while(curr.next !== null)
            {
              curr = curr.next
            }
          
          curr.next = node;
          
        }
  }

  delete(data) //remove(n) OR delete(data)
  {
    //students implement
  }

  search(predicate) 
  {
    // STUDENTS IMPLEMENT
  }

  traverse(callback) 
  {
    // STUDENTS IMPLEMENT
  }
  
  
  displaylist()
  {
    print("-----------------------------")
      print("NOW DISPLAYING:")
      print("head:")
      print(this.head)
      print("currents/whole list:")
      
      let curr = this.head;
      
      while(curr !== null)
        {
          print(curr)
        //  print(this.id)
    //      text(this.id,100,this.id*50)
          curr = curr.next;
        }
      
      print("-----------------------------")
    
  }
  
  
//   remove(n) //remove(n) OR delete(data)
//   {
//      print("-----------------")
//       print("REMOVING Link #:")
//       print(n) //data or 'n'
//       print("-----------------")
      
//       let prev = null;
//       let curr = this.head;
//       while(curr.id !== n)//keep moving if not target link
//         {
//           prev = curr;
//           curr = curr.next;
//           if(curr === null) //reached end of list?
//             {
//               return; //end
//             }
//         }
//       prev.next = curr.next //(removes link)
//   }
  
  
  
  
}